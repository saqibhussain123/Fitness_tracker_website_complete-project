import React, { useState, useEffect } from 'react'
import { Plus, Edit, Trash2, Calendar, Clock, Dumbbell } from 'lucide-react'
import WorkoutForm from '../components/Forms/WorkoutForm'
import Modal from '../components/Common/Modal'
import ConfirmDialog from '../components/Common/ConfirmDialog'
import Loading from '../components/Common/Loading'
import ExportButton from '../components/Export/ExportButton'
import { workoutAPI } from '../api/api'
import { formatDate, formatDuration } from '../utils/helpers'
import toast from 'react-hot-toast'

const Workouts = () => {
  const [workouts, setWorkouts] = useState([])
  const [loading, setLoading] = useState(true)
  const [isFormModalOpen, setIsFormModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [selectedWorkout, setSelectedWorkout] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    type: ''
  })

  useEffect(() => {
    fetchWorkouts()
  }, [filters])

  const fetchWorkouts = async () => {
    try {
      setLoading(true)
      const params = {}
      if (filters.startDate) params.startDate = filters.startDate
      if (filters.endDate) params.endDate = filters.endDate
      
      const response = await workoutAPI.getAll(params)
      setWorkouts(response.data.workouts)
    } catch (error) {
      console.error('Fetch workouts error:', error)
      toast.error('Failed to load workouts')
    } finally {
      setLoading(false)
    }
  }

  const handleCreateWorkout = () => {
    setSelectedWorkout(null)
    setIsFormModalOpen(true)
  }

  const handleEditWorkout = (workout) => {
    setSelectedWorkout(workout)
    setIsFormModalOpen(true)
  }

  const handleDeleteWorkout = (workout) => {
    setSelectedWorkout(workout)
    setIsDeleteModalOpen(true)
  }

  const handleSubmitWorkout = async (formData) => {
    try {
      setIsSubmitting(true)
      
      if (selectedWorkout) {
        await workoutAPI.update(selectedWorkout._id, formData)
        toast.success('Workout updated successfully!')
      } else {
        await workoutAPI.create(formData)
        toast.success('Workout created successfully!')
      }
      
      setIsFormModalOpen(false)
      fetchWorkouts()
    } catch (error) {
      console.error('Submit workout error:', error)
      toast.error('Failed to save workout')
    } finally {
      setIsSubmitting(false)
    }
  }

  const confirmDeleteWorkout = async () => {
    try {
      await workoutAPI.delete(selectedWorkout._id)
      toast.success('Workout deleted successfully!')
      fetchWorkouts()
    } catch (error) {
      console.error('Delete workout error:', error)
      toast.error('Failed to delete workout')
    }
  }

  const getExportData = () => {
    return workouts.map(workout => ({
      Date: formatDate(workout.date),
      Name: workout.name,
      Duration: `${workout.duration} minutes`,
      Exercises: workout.exercises.length,
      'Calories Burned': workout.totalCaloriesBurned || 0,
      Notes: workout.notes || ''
    }))
  }

  if (loading) {
    return <Loading text="Loading your workouts..." />
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Workouts
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Track and manage your workout routines
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <ExportButton 
            data={getExportData()} 
            filename="fitpulse_workouts.csv"
            type="csv"
          />
          <button
            onClick={handleCreateWorkout}
            className="btn-primary flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>Add Workout</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Start Date</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
              className="input-field"
            />
          </div>
          
          <div>
            <label className="form-label">End Date</label>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
              className="input-field"
            />
          </div>
          
          <div>
            <button
              onClick={() => setFilters({ startDate: '', endDate: '', type: '' })}
              className="btn-secondary mt-6"
            >
              Clear Filters
            </button>
          </div>
        </div>
      </div>

      {/* Workouts Grid */}
      {workouts.length === 0 ? (
        <div className="card text-center py-12">
          <Dumbbell size={64} className="mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
            No workouts found
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Start tracking your fitness journey by adding your first workout.
          </p>
          <button
            onClick={handleCreateWorkout}
            className="btn-primary"
          >
            Add Your First Workout
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {workouts.map((workout) => (
            <div key={workout._id} className="card hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg text-gray-900 dark:text-gray-100 mb-1">
                    {workout.name}
                  </h3>
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 space-x-4">
                    <div className="flex items-center space-x-1">
                      <Calendar size={14} />
                      <span>{formatDate(workout.date)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock size={14} />
                      <span>{formatDuration(workout.duration)}</span>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleEditWorkout(workout)}
                    className="text-gray-400 hover:text-primary-500 transition-colors"
                  >
                    <Edit size={18} />
                  </button>
                  <button
                    onClick={() => handleDeleteWorkout(workout)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>

              {/* Workout Stats */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                    {workout.exercises.length}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Exercises</p>
                </div>
                
                <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                  <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
                    {workout.totalCaloriesBurned || 0}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Calories</p>
                </div>
              </div>

              {/* Exercise List */}
              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700 dark:text-gray-300">
                  Exercises:
                </h4>
                {workout.exercises.slice(0, 3).map((exercise, index) => (
                  <div key={index} className="text-sm text-gray-600 dark:text-gray-400">
                    • {exercise.name} ({exercise.sets.length} sets)
                  </div>
                ))}
                {workout.exercises.length > 3 && (
                  <div className="text-sm text-gray-500 dark:text-gray-500">
                    +{workout.exercises.length - 3} more exercises
                  </div>
                )}
              </div>

              {workout.notes && (
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {workout.notes.substring(0, 100)}
                    {workout.notes.length > 100 && '...'}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Workout Form Modal */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={selectedWorkout ? 'Edit Workout' : 'Add New Workout'}
        size="xlarge"
      >
        <WorkoutForm
          onSubmit={handleSubmitWorkout}
          initialData={selectedWorkout}
          isLoading={isSubmitting}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmDialog
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDeleteWorkout}
        title="Delete Workout"
        message={`Are you sure you want to delete "${selectedWorkout?.name}"? This action cannot be undone.`}
        confirmText="Delete"
        type="danger"
      />
    </div>
  )
}

export default Workouts