import React from 'react'
import { Link } from 'react-router-dom'
import { 
  Activity, 
  Target, 
  TrendingUp, 
  Users, 
  Shield, 
  Smartphone,
  ArrowRight,
  CheckCircle
} from 'lucide-react'

const Home = () => {
  const features = [
    {
      icon: Activity,
      title: 'Workout Tracking',
      description: 'Log your exercises, sets, reps, and weights with our comprehensive workout tracker.'
    },
    {
      icon: Target,
      title: 'Goal Setting',
      description: 'Set and track your fitness goals with personalized targets and progress monitoring.'
    },
    {
      icon: TrendingUp,
      title: 'Progress Analytics',
      description: 'Visualize your fitness journey with detailed charts and progress reports.'
    },
    {
      icon: Shield,
      title: 'Secure & Private',
      description: 'Your data is secure with us. We prioritize your privacy and data protection.'
    },
    {
      icon: Smartphone,
      title: 'Mobile Friendly',
      description: 'Access FitPulse on any device. Our responsive design works everywhere.'
    },
    {
      icon: Users,
      title: 'Community Support',
      description: 'Join a community of fitness enthusiasts and share your achievements.'
    }
  ]

  const benefits = [
    'Track workouts, nutrition, and progress in one place',
    'Set personalized fitness goals and monitor achievements',
    'Generate detailed analytics and progress reports',
    'Export your data in multiple formats',
    'Secure cloud storage for all your fitness data',
    'Responsive design that works on all devices'
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Navigation */}
      <nav className="bg-white dark:bg-gray-800 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="h-8 w-8 bg-primary-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">FP</span>
              </div>
              <span className="font-bold text-xl text-gray-900 dark:text-gray-100">
                FitPulse
              </span>
            </div>
            
            <div className="flex items-center space-x-4">
              <Link
                to="/login"
                className="text-gray-700 dark:text-gray-300 hover:text-primary-500 font-medium"
              >
                Login
              </Link>
              <Link
                to="/register"
                className="btn-primary"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-16">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-gray-100 mb-6">
            Your Personal
            <span className="text-gradient block">Fitness Tracker</span>
          </h1>
          
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8 max-w-3xl mx-auto">
            Track workouts, monitor nutrition, and visualize your fitness progress all in one place. 
            Start your journey to a healthier you with FitPulse.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/register"
              className="btn-primary inline-flex items-center justify-center space-x-2 text-lg px-8 py-3"
            >
              <span>Start Free Today</span>
              <ArrowRight size={20} />
            </Link>
            
            <Link
              to="/login"
              className="btn-secondary inline-flex items-center justify-center text-lg px-8 py-3"
            >
              Sign In
            </Link>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="bg-white dark:bg-gray-800 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-4">
              Everything You Need
            </h2>
            <p className="text-lg text-gray-600 dark:text-gray-400">
              Comprehensive fitness tracking tools to help you achieve your goals
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon
              return (
                <div 
                  key={index}
                  className="bg-gray-50 dark:bg-gray-700 p-6 rounded-lg hover:shadow-lg transition-shadow"
                >
                  <Icon size={40} className="text-primary-500 mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {feature.description}
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="bg-gray-50 dark:bg-gray-900 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-gray-100 mb-6">
                Why Choose FitPulse?
              </h2>
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <CheckCircle size={20} className="text-green-500 mt-0.5 flex-shrink-0" />
                    <span className="text-gray-700 dark:text-gray-300">{benefit}</span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-white dark:bg-gray-800 p-8 rounded-lg shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">
                Ready to Get Started?
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Join thousands of users who have transformed their fitness journey with FitPulse.
              </p>
              <Link
                to="/register"
                className="btn-primary w-full justify-center"
              >
                Create Your Free Account
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 mb-4">
              <div className="h-8 w-8 bg-primary-500 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">FP</span>
              </div>
              <span className="font-bold text-xl text-gray-900 dark:text-gray-100">
                FitPulse
              </span>
            </div>
            <p className="text-gray-600 dark:text-gray-400">
              © 2024 FitPulse. Built for your fitness journey.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default Home