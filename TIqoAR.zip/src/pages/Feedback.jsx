import React, { useState, useEffect } from 'react'
import { Send, MessageSquare, Bug, Lightbulb, HelpCircle } from 'lucide-react'
import Modal from '../components/Common/Modal'
import Loading from '../components/Common/Loading'
import { feedbackAPI } from '../api/api'
import { FEEDBACK_TYPES, PRIORITY_LEVELS } from '../utils/constants'
import { formatDate } from '../utils/helpers'
import toast from 'react-hot-toast'

const Feedback = () => {
  const [feedbackList, setFeedbackList] = useState([])
  const [loading, setLoading] = useState(true)
  const [isFormModalOpen, setIsFormModalOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    type: 'general_feedback',
    subject: '',
    message: '',
    priority: 'medium'
  })

  useEffect(() => {
    fetchFeedback()
  }, [])

  const fetchFeedback = async () => {
    try {
      setLoading(true)
      const response = await feedbackAPI.getAll()
      setFeedbackList(response.data.feedback)
    } catch (error) {
      console.error('Fetch feedback error:', error)
      toast.error('Failed to load feedback')
    } finally {
      setLoading(false)
    }
  }

  const handleSubmitFeedback = async (e) => {
    e.preventDefault()
    
    if (!formData.subject.trim() || !formData.message.trim()) {
      toast.error('Please fill in all required fields')
      return
    }

    try {
      setIsSubmitting(true)
      
      await feedbackAPI.create(formData)
      toast.success('Feedback submitted successfully!')
      
      setIsFormModalOpen(false)
      setFormData({
        type: 'general_feedback',
        subject: '',
        message: '',
        priority: 'medium'
      })
      
      fetchFeedback()
    } catch (error) {
      console.error('Submit feedback error:', error)
      toast.error('Failed to submit feedback')
    } finally {
      setIsSubmitting(false)
    }
  }

  const getTypeIcon = (type) => {
    switch (type) {
      case 'bug_report':
        return <Bug className="h-5 w-5 text-red-500" />
      case 'feature_request':
        return <Lightbulb className="h-5 w-5 text-yellow-500" />
      case 'support':
        return <HelpCircle className="h-5 w-5 text-blue-500" />
      default:
        return <MessageSquare className="h-5 w-5 text-gray-500" />
    }
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'open':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
      case 'in_progress':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
      case 'resolved':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'closed':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
    }
  }

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return 'text-red-600 dark:text-red-400'
      case 'medium':
        return 'text-yellow-600 dark:text-yellow-400'
      case 'low':
        return 'text-green-600 dark:text-green-400'
      default:
        return 'text-gray-600 dark:text-gray-400'
    }
  }

  if (loading) {
    return <Loading text="Loading feedback..." />
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Feedback & Support
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Share your thoughts, report bugs, or request new features
          </p>
        </div>
        
        <button
          onClick={() => setIsFormModalOpen(true)}
          className="btn-primary flex items-center space-x-2"
        >
          <Send size={20} />
          <span>Submit Feedback</span>
        </button>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <button
          onClick={() => {
            setFormData(prev => ({ ...prev, type: 'bug_report' }))
            setIsFormModalOpen(true)
          }}
          className="card hover:shadow-lg transition-shadow text-left"
        >
          <div className="flex items-center space-x-3">
            <Bug className="h-8 w-8 text-red-500" />
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                Report Bug
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Found something broken?
              </p>
            </div>
          </div>
        </button>

        <button
          onClick={() => {
            setFormData(prev => ({ ...prev, type: 'feature_request' }))
            setIsFormModalOpen(true)
          }}
          className="card hover:shadow-lg transition-shadow text-left"
        >
          <div className="flex items-center space-x-3">
            <Lightbulb className="h-8 w-8 text-yellow-500" />
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                Request Feature
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Have an idea for improvement?
              </p>
            </div>
          </div>
        </button>

        <button
          onClick={() => {
            setFormData(prev => ({ ...prev, type: 'support' }))
            setIsFormModalOpen(true)
          }}
          className="card hover:shadow-lg transition-shadow text-left"
        >
          <div className="flex items-center space-x-3">
            <HelpCircle className="h-8 w-8 text-blue-500" />
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                Get Support
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Need help with something?
              </p>
            </div>
          </div>
        </button>

        <button
          onClick={() => {
            setFormData(prev => ({ ...prev, type: 'general_feedback' }))
            setIsFormModalOpen(true)
          }}
          className="card hover:shadow-lg transition-shadow text-left"
        >
          <div className="flex items-center space-x-3">
            <MessageSquare className="h-8 w-8 text-gray-500" />
            <div>
              <h3 className="font-medium text-gray-900 dark:text-gray-100">
                General Feedback
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Share your thoughts
              </p>
            </div>
          </div>
        </button>
      </div>

      {/* Previous Feedback */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Your Feedback History</h3>
        
        {feedbackList.length === 0 ? (
          <div className="text-center py-8">
            <MessageSquare size={48} className="mx-auto text-gray-400 mb-4" />
            <p className="text-gray-500 dark:text-gray-400">No feedback submitted yet</p>
            <p className="text-sm text-gray-400 dark:text-gray-500">
              We'd love to hear your thoughts about FitPulse!
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {feedbackList.map((feedback) => (
              <div key={feedback._id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    {getTypeIcon(feedback.type)}
                    <div>
                      <h4 className="font-medium text-gray-900 dark:text-gray-100">
                        {feedback.subject}
                      </h4>
                      <div className="flex items-center space-x-2 text-sm text-gray-600 dark:text-gray-400">
                        <span className="capitalize">{feedback.type.replace('_', ' ')}</span>
                        <span>•</span>
                        <span className={getPriorityColor(feedback.priority)}>
                          {feedback.priority} priority
                        </span>
                        <span>•</span>
                        <span>{formatDate(feedback.createdAt)}</span>
                      </div>
                    </div>
                  </div>
                  
                  <span className={`px-2 py-1 rounded text-xs font-medium capitalize ${getStatusColor(feedback.status)}`}>
                    {feedback.status.replace('_', ' ')}
                  </span>
                </div>
                
                <p className="text-gray-700 dark:text-gray-300 mb-3">
                  {feedback.message}
                </p>
                
                {feedback.response && (
                  <div className="bg-blue-50 dark:bg-blue-900 p-3 rounded-lg">
                    <h5 className="font-medium text-blue-800 dark:text-blue-200 mb-1">
                      Response:
                    </h5>
                    <p className="text-blue-700 dark:text-blue-300 text-sm">
                      {feedback.response}
                    </p>
                    {feedback.respondedAt && (
                      <p className="text-blue-600 dark:text-blue-400 text-xs mt-2">
                        Responded on {formatDate(feedback.respondedAt)}
                      </p>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Feedback Form Modal */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title="Submit Feedback"
        size="medium"
      >
        <form onSubmit={handleSubmitFeedback} className="space-y-4">
          <div>
            <label className="form-label">Type of Feedback *</label>
            <select
              value={formData.type}
              onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value }))}
              className="input-field"
              required
            >
              {FEEDBACK_TYPES.map(type => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="form-label">Subject *</label>
            <input
              type="text"
              value={formData.subject}
              onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
              className="input-field"
              required
              placeholder="Brief description of your feedback"
            />
          </div>

          <div>
            <label className="form-label">Priority</label>
            <select
              value={formData.priority}
              onChange={(e) => setFormData(prev => ({ ...prev, priority: e.target.value }))}
              className="input-field"
            >
              {PRIORITY_LEVELS.map(level => (
                <option key={level.value} value={level.value}>
                  {level.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="form-label">Message *</label>
            <textarea
              value={formData.message}
              onChange={(e) => setFormData(prev => ({ ...prev, message: e.target.value }))}
              className="input-field"
              rows="6"
              required
              placeholder="Please provide as much detail as possible..."
            />
          </div>

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => setIsFormModalOpen(false)}
              className="btn-secondary"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="btn-primary flex items-center space-x-2"
            >
              <Send size={16} />
              <span>{isSubmitting ? 'Submitting...' : 'Submit Feedback'}</span>
            </button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

export default Feedback