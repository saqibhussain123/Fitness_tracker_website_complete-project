import React, { useState, useEffect } from 'react'
import { Plus, Edit, Trash2, Calendar, TrendingUp } from 'lucide-react'
import ProgressForm from '../components/Forms/ProgressForm'
import Modal from '../components/Common/Modal'
import ConfirmDialog from '../components/Common/ConfirmDialog'
import Loading from '../components/Common/Loading'
import ExportButton from '../components/Export/ExportButton'
import WeightChart from '../components/Charts/WeightChart'
import { progressAPI } from '../api/api'
import { formatDate, getBMICategory, calculateBMI } from '../utils/helpers'
import { MOOD_OPTIONS } from '../utils/constants'
import toast from 'react-hot-toast'

const Progress = () => {
  const [progressEntries, setProgressEntries] = useState([])
  const [loading, setLoading] = useState(true)
  const [isFormModalOpen, setIsFormModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [selectedEntry, setSelectedEntry] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [stats, setStats] = useState({})
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: ''
  })

  useEffect(() => {
    fetchProgressEntries()
    fetchProgressStats()
  }, [filters])

  const fetchProgressEntries = async () => {
    try {
      setLoading(true)
      const params = {}
      if (filters.startDate) params.startDate = filters.startDate
      if (filters.endDate) params.endDate = filters.endDate
      
      const response = await progressAPI.getAll(params)
      setProgressEntries(response.data.progress)
    } catch (error) {
      console.error('Fetch progress entries error:', error)
      toast.error('Failed to load progress entries')
    } finally {
      setLoading(false)
    }
  }

  const fetchProgressStats = async () => {
    try {
      const response = await progressAPI.getStats()
      setStats(response.data)
    } catch (error) {
      console.error('Fetch progress stats error:', error)
    }
  }

  const handleCreateEntry = () => {
    setSelectedEntry(null)
    setIsFormModalOpen(true)
  }

  const handleEditEntry = (entry) => {
    setSelectedEntry(entry)
    setIsFormModalOpen(true)
  }

  const handleDeleteEntry = (entry) => {
    setSelectedEntry(entry)
    setIsDeleteModalOpen(true)
  }

  const handleSubmitEntry = async (formData) => {
    try {
      setIsSubmitting(true)
      
      if (selectedEntry) {
        await progressAPI.update(selectedEntry._id, formData)
        toast.success('Progress entry updated successfully!')
      } else {
        await progressAPI.create(formData)
        toast.success('Progress entry created successfully!')
      }
      
      setIsFormModalOpen(false)
      fetchProgressEntries()
      fetchProgressStats()
    } catch (error) {
      console.error('Submit progress entry error:', error)
      toast.error('Failed to save progress entry')
    } finally {
      setIsSubmitting(false)
    }
  }

  const confirmDeleteEntry = async () => {
    try {
      await progressAPI.delete(selectedEntry._id)
      toast.success('Progress entry deleted successfully!')
      fetchProgressEntries()
      fetchProgressStats()
    } catch (error) {
      console.error('Delete progress entry error:', error)
      toast.error('Failed to delete progress entry')
    }
  }

  const getExportData = () => {
    return progressEntries.map(entry => ({
      Date: formatDate(entry.date),
      'Weight (kg)': entry.weight,
      'Chest (cm)': entry.bodyMeasurements?.chest || '',
      'Waist (cm)': entry.bodyMeasurements?.waist || '',
      'Hips (cm)': entry.bodyMeasurements?.hips || '',
      'Body Fat %': entry.bodyFatPercentage || '',
      'Muscle Mass (kg)': entry.muscleMass || '',
      Mood: entry.mood,
      'Energy Level': entry.energyLevel,
      'Sleep Hours': entry.sleepHours || '',
      Notes: entry.notes || ''
    }))
  }

  const getMoodEmoji = (mood) => {
    const moodOption = MOOD_OPTIONS.find(option => option.value === mood)
    return moodOption ? moodOption.emoji : '😐'
  }

  if (loading) {
    return <Loading text="Loading your progress..." />
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Progress Tracking
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Monitor your body measurements and wellness metrics
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <ExportButton 
            data={getExportData()} 
            filename="fitpulse_progress.csv"
            type="csv"
          />
          <button
            onClick={handleCreateEntry}
            className="btn-primary flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>Add Progress</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      {Object.keys(stats).length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="stat-card">
            <h3 className="text-sm font-medium text-primary-700 dark:text-primary-300">
              Current Weight
            </h3>
            <p className="text-2xl font-bold text-primary-900 dark:text-primary-100">
              {stats.currentWeight} kg
            </p>
          </div>
          
          <div className="stat-card">
            <h3 className="text-sm font-medium text-primary-700 dark:text-primary-300">
              Weight Change
            </h3>
            <p className={`text-2xl font-bold ${
              stats.weightChange > 0 
                ? 'text-red-600 dark:text-red-400' 
                : stats.weightChange < 0 
                ? 'text-green-600 dark:text-green-400'
                : 'text-gray-600 dark:text-gray-400'
            }`}>
              {stats.weightChange > 0 ? '+' : ''}{stats.weightChange} kg
            </p>
          </div>
          
          <div className="stat-card">
            <h3 className="text-sm font-medium text-primary-700 dark:text-primary-300">
              Total Entries
            </h3>
            <p className="text-2xl font-bold text-primary-900 dark:text-primary-100">
              {stats.totalEntries}
            </p>
          </div>
          
          <div className="stat-card">
            <h3 className="text-sm font-medium text-primary-700 dark:text-primary-300">
              BMI
            </h3>
            <p className="text-2xl font-bold text-primary-900 dark:text-primary-100">
              {stats.currentWeight && stats.latestEntry?.height 
                ? calculateBMI(stats.currentWeight, stats.latestEntry.height)
                : 'N/A'
              }
            </p>
          </div>
        </div>
      )}

      {/* Weight Chart */}
      {stats.weightTrend && stats.weightTrend.length > 0 && (
        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Weight Progress</h3>
          <WeightChart 
            data={stats.weightTrend} 
            darkMode={document.documentElement.classList.contains('dark')}
          />
        </div>
      )}

      {/* Filters */}
      <div className="card">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Start Date</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
              className="input-field"
            />
          </div>
          
          <div>
            <label className="form-label">End Date</label>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
              className="input-field"
            />
          </div>
          
          <div>
            <button
              onClick={() => setFilters({ startDate: '', endDate: '' })}
              className="btn-secondary mt-6"
            >
              Clear Filters
            </button>
          </div>
        </div>
      </div>

      {/* Progress Entries */}
      {progressEntries.length === 0 ? (
        <div className="card text-center py-12">
          <TrendingUp size={64} className="mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
            No progress entries found
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Start tracking your progress by recording your first measurements.
          </p>
          <button
            onClick={handleCreateEntry}
            className="btn-primary"
          >
            Record First Progress
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {progressEntries.map((entry) => (
            <div key={entry._id} className="card hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 mb-2">
                    <Calendar size={14} className="mr-1" />
                    <span>{formatDate(entry.date)}</span>
                  </div>
                  <h3 className="font-semibold text-lg text-gray-900 dark:text-gray-100">
                    Progress Entry
                  </h3>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleEditEntry(entry)}
                    className="text-gray-400 hover:text-primary-500 transition-colors"
                  >
                    <Edit size={18} />
                  </button>
                  <button
                    onClick={() => handleDeleteEntry(entry)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>

              {/* Weight and BMI */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="text-center p-3 bg-blue-50 dark:bg-blue-900 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {entry.weight}
                  </p>
                  <p className="text-sm text-blue-700 dark:text-blue-300">Weight (kg)</p>
                </div>
                
                {entry.bodyFatPercentage && (
                  <div className="text-center p-3 bg-purple-50 dark:bg-purple-900 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                      {entry.bodyFatPercentage}%
                    </p>
                    <p className="text-sm text-purple-700 dark:text-purple-300">Body Fat</p>
                  </div>
                )}
              </div>

              {/* Body Measurements */}
              {entry.bodyMeasurements && Object.values(entry.bodyMeasurements).some(val => val) && (
                <div className="mb-4">
                  <h4 className="font-medium text-sm text-gray-700 dark:text-gray-300 mb-2">
                    Measurements (cm):
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {entry.bodyMeasurements.chest && (
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Chest:</span>
                        <span className="text-gray-800 dark:text-gray-200">{entry.bodyMeasurements.chest}</span>
                      </div>
                    )}
                    {entry.bodyMeasurements.waist && (
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Waist:</span>
                        <span className="text-gray-800 dark:text-gray-200">{entry.bodyMeasurements.waist}</span>
                      </div>
                    )}
                    {entry.bodyMeasurements.hips && (
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Hips:</span>
                        <span className="text-gray-800 dark:text-gray-200">{entry.bodyMeasurements.hips}</span>
                      </div>
                    )}
                    {entry.bodyMeasurements.biceps && (
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Biceps:</span>
                        <span className="text-gray-800 dark:text-gray-200">{entry.bodyMeasurements.biceps}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Wellness Metrics */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <p className="text-lg">{getMoodEmoji(entry.mood)}</p>
                  <p className="text-xs text-gray-600 dark:text-gray-400 capitalize">{entry.mood}</p>
                </div>
                
                <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <p className="font-bold text-yellow-600 dark:text-yellow-400">
                    {entry.energyLevel}/10
                  </p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Energy</p>
                </div>
                
                {entry.sleepHours && (
                  <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                    <p className="font-bold text-indigo-600 dark:text-indigo-400">
                      {entry.sleepHours}h
                    </p>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Sleep</p>
                  </div>
                )}
              </div>

              {entry.notes && (
                <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {entry.notes.substring(0, 100)}
                    {entry.notes.length > 100 && '...'}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Progress Form Modal */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={selectedEntry ? 'Edit Progress Entry' : 'Add New Progress Entry'}
        size="large"
      >
        <ProgressForm
          onSubmit={handleSubmitEntry}
          initialData={selectedEntry}
          isLoading={isSubmitting}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmDialog
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDeleteEntry}
        title="Delete Progress Entry"
        message={`Are you sure you want to delete this progress entry for ${selectedEntry ? formatDate(selectedEntry.date) : ''}? This action cannot be undone.`}
        confirmText="Delete"
        type="danger"
      />
    </div>
  )
}

export default Progress