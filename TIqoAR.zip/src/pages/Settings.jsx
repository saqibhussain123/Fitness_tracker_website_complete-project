import React, { useState, useEffect } from 'react'
import { Save, Trash2, AlertTriangle } from 'lucide-react'
import ConfirmDialog from '../components/Common/ConfirmDialog'
import Loading from '../components/Common/Loading'
import { userAPI } from '../api/api'
import { useAuth } from '../context/AuthContext'
import { UNITS } from '../utils/constants'
import toast from 'react-hot-toast'

const Settings = () => {
  const { user, updateUser, logout } = useAuth()
  const [loading, setLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [settings, setSettings] = useState({
    units: 'metric',
    theme: 'light',
    notifications: {
      workoutReminders: true,
      nutritionReminders: true,
      progressReminders: true
    }
  })

  useEffect(() => {
    fetchUserData()
  }, [])

  const fetchUserData = async () => {
    try {
      setLoading(true)
      const response = await userAPI.getProfile()
      setSettings(response.data.settings || settings)
    } catch (error) {
      console.error('Fetch user data error:', error)
      toast.error('Failed to load settings')
    } finally {
      setLoading(false)
    }
  }

  const handleSaveSettings = async () => {
    try {
      setIsSubmitting(true)
      
      const response = await userAPI.updateSettings(settings)
      updateUser(response.data.user)
      
      // Apply theme change immediately
      if (settings.theme === 'dark') {
        document.documentElement.classList.add('dark')
      } else {
        document.documentElement.classList.remove('dark')
      }
      
      toast.success('Settings saved successfully!')
    } catch (error) {
      console.error('Save settings error:', error)
      toast.error('Failed to save settings')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteAccount = async () => {
    try {
      await userAPI.deleteAccount()
      toast.success('Account deleted successfully')
      logout()
    } catch (error) {
      console.error('Delete account error:', error)
      toast.error('Failed to delete account')
    }
  }

  const handleSettingChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      [field]: value
    }))
  }

  const handleNotificationChange = (field, value) => {
    setSettings(prev => ({
      ...prev,
      notifications: {
        ...prev.notifications,
        [field]: value
      }
    }))
  }

  if (loading) {
    return <Loading text="Loading settings..." />
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
          Settings
        </h1>
        <p className="text-gray-600 dark:text-gray-400">
          Manage your app preferences and account settings
        </p>
      </div>

      {/* App Preferences */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">App Preferences</h3>
        
        <div className="space-y-6">
          {/* Units */}
          <div>
            <label className="form-label">Measurement Units</label>
            <select
              value={settings.units}
              onChange={(e) => handleSettingChange('units', e.target.value)}
              className="input-field max-w-xs"
            >
              {UNITS.map(unit => (
                <option key={unit.value} value={unit.value}>
                  {unit.label}
                </option>
              ))}
            </select>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Choose between metric (kg, cm) or imperial (lbs, ft) units
            </p>
          </div>

          {/* Theme */}
          <div>
            <label className="form-label">Theme</label>
            <select
              value={settings.theme}
              onChange={(e) => handleSettingChange('theme', e.target.value)}
              className="input-field max-w-xs"
            >
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              Choose your preferred color theme
            </p>
          </div>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Notification Preferences</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div>
              <h4 className="font-medium text-gray-900 dark:text-gray-100">
                Workout Reminders
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get reminded to log your workouts
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.notifications.workoutReminders}
                onChange={(e) => handleNotificationChange('workoutReminders', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div>
              <h4 className="font-medium text-gray-900 dark:text-gray-100">
                Nutrition Reminders
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get reminded to log your meals
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.notifications.nutritionReminders}
                onChange={(e) => handleNotificationChange('nutritionReminders', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
            </label>
          </div>

          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div>
              <h4 className="font-medium text-gray-900 dark:text-gray-100">
                Progress Reminders
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get reminded to track your progress
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.notifications.progressReminders}
                onChange={(e) => handleNotificationChange('progressReminders', e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 dark:peer-focus:ring-primary-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-primary-600"></div>
            </label>
          </div>
        </div>
      </div>

      {/* Save Settings */}
      <div className="card">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Save Changes</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Click save to apply your settings
            </p>
          </div>
          
          <button
            onClick={handleSaveSettings}
            disabled={isSubmitting}
            className="btn-primary flex items-center space-x-2"
          >
            <Save size={20} />
            <span>{isSubmitting ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </div>

      {/* Data Management */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Data Management</h3>
        
        <div className="space-y-4">
          <div className="p-4 bg-blue-50 dark:bg-blue-900 rounded-lg">
            <h4 className="font-medium text-blue-800 dark:text-blue-200 mb-2">
              Export Your Data
            </h4>
            <p className="text-sm text-blue-700 dark:text-blue-300 mb-3">
              You can export your fitness data from the individual pages (Workouts, Nutrition, Progress, Analytics).
            </p>
            <p className="text-sm text-blue-700 dark:text-blue-300">
              Look for the "Export CSV" or "Export PDF" buttons on each page.
            </p>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="card border-red-200 dark:border-red-800">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="h-6 w-6 text-red-500 mt-1" />
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-red-800 dark:text-red-200 mb-2">
              Danger Zone
            </h3>
            <p className="text-sm text-red-700 dark:text-red-300 mb-4">
              Once you delete your account, there is no going back. Please be certain.
            </p>
            
            <button
              onClick={() => setIsDeleteModalOpen(true)}
              className="btn-danger flex items-center space-x-2"
            >
              <Trash2 size={20} />
              <span>Delete Account</span>
            </button>
          </div>
        </div>
      </div>

      {/* Delete Account Confirmation */}
      <ConfirmDialog
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={handleDeleteAccount}
        title="Delete Account"
        message="Are you absolutely sure you want to delete your account? This action cannot be undone and you will lose all your data including workouts, nutrition logs, and progress entries."
        confirmText="Delete Account"
        type="danger"
      />
    </div>
  )
}

export default Settings