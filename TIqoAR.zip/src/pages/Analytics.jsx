import React, { useState, useEffect } from 'react'
import { BarChart3, TrendingUp, Calendar, Activity } from 'lucide-react'
import WeightChart from '../components/Charts/WeightChart'
import WorkoutChart from '../components/Charts/WorkoutChart'
import CalorieChart from '../components/Charts/CalorieChart'
import Loading from '../components/Common/Loading'
import ExportButton from '../components/Export/ExportButton'
import { workoutAPI, nutritionAPI, progressAPI } from '../api/api'
import { formatDate } from '../utils/helpers'
import toast from 'react-hot-toast'

const Analytics = () => {
  const [loading, setLoading] = useState(true)
  const [dateRange, setDateRange] = useState('30') // days
  const [analyticsData, setAnalyticsData] = useState({
    weightProgress: [],
    workoutFrequency: [],
    calorieBalance: [],
    summary: {}
  })

  useEffect(() => {
    fetchAnalyticsData()
  }, [dateRange])

  const fetchAnalyticsData = async () => {
    try {
      setLoading(true)
      
      const endDate = new Date()
      const startDate = new Date()
      startDate.setDate(startDate.getDate() - parseInt(dateRange))
      
      const params = {
        startDate: startDate.toISOString().split('T')[0],
        endDate: endDate.toISOString().split('T')[0]
      }

      const [workoutRes, nutritionRes, progressRes] = await Promise.all([
        workoutAPI.getAll(params),
        nutritionAPI.getAll(params),
        progressAPI.getAll(params)
      ])

      // Process data for charts
      const weightProgress = progressRes.data.progress.map(entry => ({
        date: entry.date,
        weight: entry.weight
      })).reverse()

      // Generate workout frequency data (workouts per day for last 7 days)
      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = new Date()
        date.setDate(date.getDate() - i)
        return date.toISOString().split('T')[0]
      }).reverse()

      const workoutFrequency = last7Days.map(date => {
        const dayName = new Date(date).toLocaleDateString('en-US', { weekday: 'short' })
        const workoutsOnDay = workoutRes.data.workouts.filter(workout => 
          new Date(workout.date).toISOString().split('T')[0] === date
        ).length
        
        return {
          day: dayName,
          count: workoutsOnDay
        }
      })

      // Generate calorie balance data
      const calorieBalance = nutritionRes.data.logs.map(log => {
        const workoutsOnDay = workoutRes.data.workouts.filter(workout =>
          new Date(workout.date).toISOString().split('T')[0] === 
          new Date(log.date).toISOString().split('T')[0]
        )
        const caloriesBurned = workoutsOnDay.reduce((sum, w) => sum + (w.totalCaloriesBurned || 0), 0)
        
        return {
          date: log.date,
          consumed: log.totalCalories,
          burned: caloriesBurned
        }
      }).reverse()

      // Calculate summary statistics
      const summary = {
        totalWorkouts: workoutRes.data.workouts.length,
        avgWorkoutDuration: workoutRes.data.workouts.length > 0 
          ? Math.round(workoutRes.data.workouts.reduce((sum, w) => sum + w.duration, 0) / workoutRes.data.workouts.length)
          : 0,
        totalCaloriesBurned: workoutRes.data.workouts.reduce((sum, w) => sum + (w.totalCaloriesBurned || 0), 0),
        avgDailyCalories: nutritionRes.data.logs.length > 0
          ? Math.round(nutritionRes.data.logs.reduce((sum, l) => sum + l.totalCalories, 0) / nutritionRes.data.logs.length)
          : 0,
        weightChange: weightProgress.length > 1
          ? Math.round((weightProgress[weightProgress.length - 1].weight - weightProgress[0].weight) * 10) / 10
          : 0,
        progressEntries: progressRes.data.progress.length
      }

      setAnalyticsData({
        weightProgress,
        workoutFrequency,
        calorieBalance,
        summary
      })
    } catch (error) {
      console.error('Fetch analytics data error:', error)
      toast.error('Failed to load analytics data')
    } finally {
      setLoading(false)
    }
  }

  const getExportData = () => {
    return [
      {
        Metric: 'Total Workouts',
        Value: analyticsData.summary.totalWorkouts,
        Period: `Last ${dateRange} days`
      },
      {
        Metric: 'Average Workout Duration',
        Value: `${analyticsData.summary.avgWorkoutDuration} minutes`,
        Period: `Last ${dateRange} days`
      },
      {
        Metric: 'Total Calories Burned',
        Value: analyticsData.summary.totalCaloriesBurned,
        Period: `Last ${dateRange} days`
      },
      {
        Metric: 'Average Daily Calories',
        Value: analyticsData.summary.avgDailyCalories,
        Period: `Last ${dateRange} days`
      },
      {
        Metric: 'Weight Change',
        Value: `${analyticsData.summary.weightChange} kg`,
        Period: `Last ${dateRange} days`
      },
      {
        Metric: 'Progress Entries',
        Value: analyticsData.summary.progressEntries,
        Period: `Last ${dateRange} days`
      }
    ]
  }

  if (loading) {
    return <Loading text="Generating your analytics..." />
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Analytics
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Comprehensive insights into your fitness journey
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="input-field w-auto"
          >
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="90">Last 90 days</option>
            <option value="365">Last year</option>
          </select>
          
          <ExportButton 
            data={getExportData()} 
            filename="fitpulse_analytics.csv"
            type="csv"
          />
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        <div className="card text-center">
          <Activity className="h-8 w-8 text-blue-500 mx-auto mb-2" />
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {analyticsData.summary.totalWorkouts}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Total Workouts
          </p>
        </div>
        
        <div className="card text-center">
          <Clock className="h-8 w-8 text-green-500 mx-auto mb-2" />
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {analyticsData.summary.avgWorkoutDuration}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Avg Duration (min)
          </p>
        </div>
        
        <div className="card text-center">
          <div className="h-8 w-8 text-orange-500 mx-auto mb-2 text-2xl">🔥</div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {analyticsData.summary.totalCaloriesBurned}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Calories Burned
          </p>
        </div>
        
        <div className="card text-center">
          <div className="h-8 w-8 text-yellow-500 mx-auto mb-2 text-2xl">🍎</div>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {analyticsData.summary.avgDailyCalories}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Avg Daily Calories
          </p>
        </div>
        
        <div className="card text-center">
          <TrendingUp className={`h-8 w-8 mx-auto mb-2 ${
            analyticsData.summary.weightChange > 0 ? 'text-red-500' :
            analyticsData.summary.weightChange < 0 ? 'text-green-500' :
            'text-gray-500'
          }`} />
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {analyticsData.summary.weightChange > 0 ? '+' : ''}{analyticsData.summary.weightChange}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Weight Change (kg)
          </p>
        </div>
        
        <div className="card text-center">
          <BarChart3 className="h-8 w-8 text-purple-500 mx-auto mb-2" />
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {analyticsData.summary.progressEntries}
          </p>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Progress Entries
          </p>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weight Progress Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Weight Progress</h3>
          {analyticsData.weightProgress.length > 0 ? (
            <WeightChart 
              data={analyticsData.weightProgress}
              darkMode={document.documentElement.classList.contains('dark')}
            />
          ) : (
            <div className="chart-container flex items-center justify-center">
              <p className="text-gray-500 dark:text-gray-400">No weight data available</p>
            </div>
          )}
        </div>

        {/* Workout Frequency Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Weekly Workout Frequency</h3>
          <WorkoutChart 
            data={analyticsData.workoutFrequency}
            darkMode={document.documentElement.classList.contains('dark')}
          />
        </div>
      </div>

      {/* Calorie Balance Chart */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Calorie Balance</h3>
        {analyticsData.calorieBalance.length > 0 ? (
          <CalorieChart 
            data={analyticsData.calorieBalance}
            darkMode={document.documentElement.classList.contains('dark')}
          />
        ) : (
          <div className="chart-container flex items-center justify-center">
            <p className="text-gray-500 dark:text-gray-400">No calorie data available</p>
          </div>
        )}
      </div>

      {/* Insights */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Insights & Recommendations</h3>
        <div className="space-y-3">
          {analyticsData.summary.totalWorkouts === 0 && (
            <div className="p-4 bg-yellow-50 dark:bg-yellow-900 rounded-lg">
              <p className="text-yellow-800 dark:text-yellow-200">
                💡 <strong>Get Started:</strong> You haven't logged any workouts yet. Start by adding your first workout to begin tracking your progress!
              </p>
            </div>
          )}
          
          {analyticsData.summary.totalWorkouts > 0 && analyticsData.summary.totalWorkouts < 5 && (
            <div className="p-4 bg-blue-50 dark:bg-blue-900 rounded-lg">
              <p className="text-blue-800 dark:text-blue-200">
                🚀 <strong>Building Momentum:</strong> Great start! Try to maintain consistency by working out at least 3-4 times per week.
              </p>
            </div>
          )}
          
          {analyticsData.summary.avgWorkoutDuration > 0 && analyticsData.summary.avgWorkoutDuration < 30 && (
            <div className="p-4 bg-green-50 dark:bg-green-900 rounded-lg">
              <p className="text-green-800 dark:text-green-200">
                ⏱️ <strong>Duration Tip:</strong> Consider extending your workouts to 30-45 minutes for optimal benefits.
              </p>
            </div>
          )}
          
          {analyticsData.summary.weightChange > 0 && (
            <div className="p-4 bg-orange-50 dark:bg-orange-900 rounded-lg">
              <p className="text-orange-800 dark:text-orange-200">
                📈 <strong>Weight Trend:</strong> You've gained {analyticsData.summary.weightChange}kg. If this aligns with your goals (muscle building), great! Otherwise, consider reviewing your nutrition.
              </p>
            </div>
          )}
          
          {analyticsData.summary.weightChange < 0 && (
            <div className="p-4 bg-green-50 dark:bg-green-900 rounded-lg">
              <p className="text-green-800 dark:text-green-200">
                📉 <strong>Weight Loss:</strong> You've lost {Math.abs(analyticsData.summary.weightChange)}kg! Keep up the great work and maintain a balanced approach.
              </p>
            </div>
          )}
          
          {analyticsData.summary.progressEntries === 0 && (
            <div className="p-4 bg-purple-50 dark:bg-purple-900 rounded-lg">
              <p className="text-purple-800 dark:text-purple-200">
                📊 <strong>Track Progress:</strong> Consider logging your body measurements and weight regularly to better track your progress over time.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Analytics