import React, { useState, useEffect } from 'react'
import { Plus, Edit, Trash2, Calendar, Apple } from 'lucide-react'
import NutritionForm from '../components/Forms/NutritionForm'
import Modal from '../components/Common/Modal'
import ConfirmDialog from '../components/Common/ConfirmDialog'
import Loading from '../components/Common/Loading'
import ExportButton from '../components/Export/ExportButton'
import { nutritionAPI } from '../api/api'
import { formatDate } from '../utils/helpers'
import toast from 'react-hot-toast'

const Nutrition = () => {
  const [nutritionLogs, setNutritionLogs] = useState([])
  const [loading, setLoading] = useState(true)
  const [isFormModalOpen, setIsFormModalOpen] = useState(false)
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false)
  const [selectedLog, setSelectedLog] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: ''
  })

  useEffect(() => {
    fetchNutritionLogs()
  }, [filters])

  const fetchNutritionLogs = async () => {
    try {
      setLoading(true)
      const params = {}
      if (filters.startDate) params.startDate = filters.startDate
      if (filters.endDate) params.endDate = filters.endDate
      
      const response = await nutritionAPI.getAll(params)
      setNutritionLogs(response.data.logs)
    } catch (error) {
      console.error('Fetch nutrition logs error:', error)
      toast.error('Failed to load nutrition logs')
    } finally {
      setLoading(false)
    }
  }

  const handleCreateLog = () => {
    setSelectedLog(null)
    setIsFormModalOpen(true)
  }

  const handleEditLog = (log) => {
    setSelectedLog(log)
    setIsFormModalOpen(true)
  }

  const handleDeleteLog = (log) => {
    setSelectedLog(log)
    setIsDeleteModalOpen(true)
  }

  const handleSubmitLog = async (formData) => {
    try {
      setIsSubmitting(true)
      
      if (selectedLog) {
        await nutritionAPI.update(selectedLog._id, formData)
        toast.success('Nutrition log updated successfully!')
      } else {
        await nutritionAPI.create(formData)
        toast.success('Nutrition log created successfully!')
      }
      
      setIsFormModalOpen(false)
      fetchNutritionLogs()
    } catch (error) {
      console.error('Submit nutrition log error:', error)
      toast.error('Failed to save nutrition log')
    } finally {
      setIsSubmitting(false)
    }
  }

  const confirmDeleteLog = async () => {
    try {
      await nutritionAPI.delete(selectedLog._id)
      toast.success('Nutrition log deleted successfully!')
      fetchNutritionLogs()
    } catch (error) {
      console.error('Delete nutrition log error:', error)
      toast.error('Failed to delete nutrition log')
    }
  }

  const getExportData = () => {
    return nutritionLogs.map(log => ({
      Date: formatDate(log.date),
      'Total Calories': log.totalCalories,
      'Protein (g)': log.totalMacros.protein,
      'Carbs (g)': log.totalMacros.carbs,
      'Fat (g)': log.totalMacros.fat,
      'Fiber (g)': log.totalMacros.fiber,
      'Water (L)': log.waterIntake,
      Notes: log.notes || ''
    }))
  }

  const getTotalFoodItems = (meals) => {
    return Object.values(meals).reduce((total, meal) => total + meal.length, 0)
  }

  if (loading) {
    return <Loading text="Loading your nutrition logs..." />
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Nutrition
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Track your daily meals and nutrition intake
          </p>
        </div>
        
        <div className="flex items-center space-x-3">
          <ExportButton 
            data={getExportData()} 
            filename="fitpulse_nutrition.csv"
            type="csv"
          />
          <button
            onClick={handleCreateLog}
            className="btn-primary flex items-center space-x-2"
          >
            <Plus size={20} />
            <span>Add Nutrition Log</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="card">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Start Date</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
              className="input-field"
            />
          </div>
          
          <div>
            <label className="form-label">End Date</label>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
              className="input-field"
            />
          </div>
          
          <div>
            <button
              onClick={() => setFilters({ startDate: '', endDate: '' })}
              className="btn-secondary mt-6"
            >
              Clear Filters
            </button>
          </div>
        </div>
      </div>

      {/* Nutrition Logs Grid */}
      {nutritionLogs.length === 0 ? (
        <div className="card text-center py-12">
          <Apple size={64} className="mx-auto text-gray-400 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
            No nutrition logs found
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Start tracking your nutrition by logging your first meal.
          </p>
          <button
            onClick={handleCreateLog}
            className="btn-primary"
          >
            Log Your First Meal
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {nutritionLogs.map((log) => (
            <div key={log._id} className="card hover:shadow-lg transition-shadow">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center text-sm text-gray-600 dark:text-gray-400 mb-2">
                    <Calendar size={14} className="mr-1" />
                    <span>{formatDate(log.date)}</span>
                  </div>
                  <h3 className="font-semibold text-lg text-gray-900 dark:text-gray-100">
                    Daily Nutrition
                  </h3>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleEditLog(log)}
                    className="text-gray-400 hover:text-primary-500 transition-colors"
                  >
                    <Edit size={18} />
                  </button>
                  <button
                    onClick={() => handleDeleteLog(log)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
              </div>

              {/* Nutrition Stats */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="text-center p-3 bg-green-50 dark:bg-green-900 rounded-lg">
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                    {log.totalCalories}
                  </p>
                  <p className="text-sm text-green-700 dark:text-green-300">Calories</p>
                </div>
                
                <div className="text-center p-3 bg-blue-50 dark:bg-blue-900 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                    {getTotalFoodItems(log.meals)}
                  </p>
                  <p className="text-sm text-blue-700 dark:text-blue-300">Food Items</p>
                </div>
              </div>

              {/* Macros */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <p className="font-bold text-orange-600 dark:text-orange-400">
                    {log.totalMacros.protein}g
                  </p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Protein</p>
                </div>
                
                <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <p className="font-bold text-yellow-600 dark:text-yellow-400">
                    {log.totalMacros.carbs}g
                  </p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Carbs</p>
                </div>
                
                <div className="text-center p-2 bg-gray-50 dark:bg-gray-700 rounded">
                  <p className="font-bold text-red-600 dark:text-red-400">
                    {log.totalMacros.fat}g
                  </p>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Fat</p>
                </div>
              </div>

              {/* Meals Summary */}
              <div className="space-y-2">
                <h4 className="font-medium text-sm text-gray-700 dark:text-gray-300">
                  Meals:
                </h4>
                {Object.entries(log.meals).map(([mealType, items]) => (
                  <div key={mealType} className="flex justify-between text-sm">
                    <span className="capitalize text-gray-600 dark:text-gray-400">
                      {mealType}:
                    </span>
                    <span className="text-gray-800 dark:text-gray-200">
                      {items.length} items
                    </span>
                  </div>
                ))}
              </div>

              {/* Water Intake */}
              {log.waterIntake > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <div className="flex items-center justify-center space-x-2 text-blue-600 dark:text-blue-400">
                    <span className="text-lg">💧</span>
                    <span className="font-medium">{log.waterIntake}L water</span>
                  </div>
                </div>
              )}

              {log.notes && (
                <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {log.notes.substring(0, 100)}
                    {log.notes.length > 100 && '...'}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Nutrition Form Modal */}
      <Modal
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        title={selectedLog ? 'Edit Nutrition Log' : 'Add New Nutrition Log'}
        size="xlarge"
      >
        <NutritionForm
          onSubmit={handleSubmitLog}
          initialData={selectedLog}
          isLoading={isSubmitting}
        />
      </Modal>

      {/* Delete Confirmation Modal */}
      <ConfirmDialog
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDeleteLog}
        title="Delete Nutrition Log"
        message={`Are you sure you want to delete this nutrition log for ${selectedLog ? formatDate(selectedLog.date) : ''}? This action cannot be undone.`}
        confirmText="Delete"
        type="danger"
      />
    </div>
  )
}

export default Nutrition