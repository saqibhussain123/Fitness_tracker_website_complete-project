import React, { useState, useEffect } from 'react'
import { Activity, Target, TrendingUp, Calendar } from 'lucide-react'
import DashboardCard from '../components/Dashboard/DashboardCard'
import RecentActivity from '../components/Dashboard/RecentActivity'
import QuickStats from '../components/Dashboard/QuickStats'
import WeightChart from '../components/Charts/WeightChart'
import Loading from '../components/Common/Loading'
import { workoutAPI, nutritionAPI, progressAPI } from '../api/api'
import { useAuth } from '../context/AuthContext'
import toast from 'react-hot-toast' 

const Dashboard = () => {
  const { user } = useAuth()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState({
    workoutStats: {},
    nutritionStats: {},
    progressStats: {},
    recentActivity: [],
    weeklyProgress: []
  })

  useEffect(() => {
    fetchDashboardData()
  }, [])

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      
      const [workoutRes, nutritionRes, progressRes] = await Promise.all([
        workoutAPI.getStats(),
        nutritionAPI.getStats(),
        progressAPI.getStats()
      ])

      // Mock recent activity - you can replace with real API calls
      const recentActivity = [
        {
          type: 'workout',
          title: 'Completed Morning Run',
          description: '5km run in 25 minutes',
          date: new Date()
        },
        {
          type: 'nutrition',
          title: 'Logged Breakfast',
          description: '350 calories, 12g protein',
          date: new Date(Date.now() - 2 * 60 * 60 * 1000)
        }
      ]

      setData({
        workoutStats: workoutRes.data.stats,
        nutritionStats: nutritionRes.data.stats,
        progressStats: progressRes.data,
        recentActivity,
        weeklyProgress: progressRes.data.weightTrend || []
      })
    } catch (error) {
      console.error('Dashboard data fetch error:', error)
      toast.error('Failed to load dashboard data')
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <Loading text="Loading your dashboard..." />
  }

  const quickStats = {
    workoutsThisWeek: data.workoutStats.totalWorkouts || 0,
    streakDays: 7, // You can calculate this from actual data
    totalWorkouts: data.workoutStats.totalWorkouts || 0,
    caloriesBurned: data.workoutStats.totalCalories || 0
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-primary-500 to-primary-600 rounded-lg p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">
          Welcome back, {user?.name}! 👋
        </h1>
        <p className="text-primary-100">
          Ready to continue your fitness journey? Let's see how you're doing.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <DashboardCard
          title="Total Workouts"
          value={data.workoutStats.totalWorkouts || 0}
          subtitle="All time"
          icon={Activity}
          color="blue"
        />
        
        <DashboardCard
          title="Avg Duration"
          value={`${Math.round(data.workoutStats.avgDuration || 0)} min`}
          subtitle="Per workout"
          icon={Target}
          color="green"
        />
        
        <DashboardCard
          title="Current Weight"
          value={`${data.progressStats.currentWeight || 0} kg`}
          subtitle={`Goal: ${user?.profile?.targetWeight || 0} kg`}
          icon={TrendingUp}
          color="orange"
          trend={{
            direction: data.progressStats.weightChange > 0 ? 'up' : data.progressStats.weightChange < 0 ? 'down' : 'same',
            value: `${Math.abs(data.progressStats.weightChange || 0)} kg`
          }}
        />
        
        <DashboardCard
          title="Calories Burned"
          value={data.workoutStats.totalCalories || 0}
          subtitle="Total"
          icon={Calendar}
          color="red"
        />
      </div>

      {/* Charts and Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weight Progress Chart */}
        <div className="card">
          <h3 className="text-lg font-semibold mb-4">Weight Progress</h3>
          <WeightChart 
            data={data.weeklyProgress} 
            darkMode={document.documentElement.classList.contains('dark')}
          />
        </div>

        {/* Quick Stats */}
        <QuickStats stats={quickStats} />
      </div>

      {/* Recent Activity */}
      <RecentActivity activities={data.recentActivity} />
    </div>
  )
}

export default Dashboard