import React, { useState, useEffect } from 'react'
import { User, Mail, Calendar, Ruler, Target } from 'lucide-react'
import ProfileForm from '../components/Forms/ProfileForm'
import Loading from '../components/Common/Loading'
import { userAPI } from '../api/api'
import { useAuth } from '../context/AuthContext'
import { calculateBMI, getBMICategory, formatHeight, formatWeight } from '../utils/helpers'
import toast from 'react-hot-toast'

const Profile = () => {
  const { user, updateUser } = useAuth()
  const [isEditing, setIsEditing] = useState(false)
  const [loading, setLoading] = useState(true)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [profileData, setProfileData] = useState(null)

  useEffect(() => {
    fetchProfile()
  }, [])

  const fetchProfile = async () => {
    try {
      setLoading(true)
      const response = await userAPI.getProfile()
      setProfileData(response.data)
    } catch (error) {
      console.error('Fetch profile error:', error)
      toast.error('Failed to load profile')
    } finally {
      setLoading(false)
    }
  }

  const handleUpdateProfile = async (formData) => {
    try {
      setIsSubmitting(true)
      
      const response = await userAPI.updateProfile(formData)
      setProfileData(response.data.user)
      updateUser(response.data.user)
      
      toast.success('Profile updated successfully!')
      setIsEditing(false)
    } catch (error) {
      console.error('Update profile error:', error)
      toast.error('Failed to update profile')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (loading) {
    return <Loading text="Loading your profile..." />
  }

  if (!profileData) {
    return (
      <div className="card text-center py-12">
        <p className="text-gray-500 dark:text-gray-400">Failed to load profile data</p>
      </div>
    )
  }

  const bmi = calculateBMI(profileData.profile?.currentWeight, profileData.profile?.height)
  const bmiCategory = getBMICategory(bmi)

  if (isEditing) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              Edit Profile
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Update your personal information and preferences
            </p>
          </div>
          
          <button
            onClick={() => setIsEditing(false)}
            className="btn-secondary"
          >
            Cancel
          </button>
        </div>

        <ProfileForm
          onSubmit={handleUpdateProfile}
          initialData={profileData}
          isLoading={isSubmitting}
        />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            Profile
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Manage your personal information and preferences
          </p>
        </div>
        
        <button
          onClick={() => setIsEditing(true)}
          className="btn-primary"
        >
          Edit Profile
        </button>
      </div>

      {/* Profile Overview */}
      <div className="card">
        <div className="flex items-center space-x-6 mb-6">
          <div className="h-20 w-20 bg-primary-500 rounded-full flex items-center justify-center">
            <User size={40} className="text-white" />
          </div>
          
          <div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">
              {profileData.name}
            </h2>
            <div className="flex items-center space-x-1 text-gray-600 dark:text-gray-400">
              <Mail size={16} />
              <span>{profileData.email}</span>
            </div>
            {profileData.profile?.age && (
              <div className="flex items-center space-x-1 text-gray-600 dark:text-gray-400">
                <Calendar size={16} />
                <span>{profileData.profile.age} years old</span>
              </div>
            )}
          </div>
        </div>

        {/* Basic Stats */}
        {(profileData.profile?.height || profileData.profile?.currentWeight) && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {profileData.profile.height && (
              <div className="text-center p-4 bg-blue-50 dark:bg-blue-900 rounded-lg">
                <Ruler className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {formatHeight(profileData.profile.height, profileData.settings?.units)}
                </p>
                <p className="text-sm text-blue-700 dark:text-blue-300">Height</p>
              </div>
            )}
            
            {profileData.profile.currentWeight && (
              <div className="text-center p-4 bg-green-50 dark:bg-green-900 rounded-lg">
                <Weight className="h-8 w-8 text-green-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {formatWeight(profileData.profile.currentWeight, profileData.settings?.units)}
                </p>
                <p className="text-sm text-green-700 dark:text-green-300">Current Weight</p>
              </div>
            )}
            
            {profileData.profile.targetWeight && (
              <div className="text-center p-4 bg-orange-50 dark:bg-orange-900 rounded-lg">
                <Target className="h-8 w-8 text-orange-500 mx-auto mb-2" />
                <p className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                  {formatWeight(profileData.profile.targetWeight, profileData.settings?.units)}
                </p>
                <p className="text-sm text-orange-700 dark:text-orange-300">Target Weight</p>
              </div>
            )}
            
            {bmi > 0 && (
              <div className="text-center p-4 bg-purple-50 dark:bg-purple-900 rounded-lg">
                <div className="h-8 w-8 text-purple-500 mx-auto mb-2 text-2xl">📊</div>
                <p className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                  {bmi}
                </p>
                <p className="text-sm text-purple-700 dark:text-purple-300">
                  BMI ({bmiCategory})
                </p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Personal Information */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Personal Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="form-label">Gender</label>
            <p className="text-gray-900 dark:text-gray-100 capitalize">
              {profileData.profile?.gender || 'Not specified'}
            </p>
          </div>
          
          <div>
            <label className="form-label">Activity Level</label>
            <p className="text-gray-900 dark:text-gray-100 capitalize">
              {profileData.profile?.activityLevel?.replace('_', ' ') || 'Not specified'}
            </p>
          </div>
          
          <div>
            <label className="form-label">Fitness Goal</label>
            <p className="text-gray-900 dark:text-gray-100 capitalize">
              {profileData.profile?.fitnessGoal?.replace('_', ' ') || 'Not specified'}
            </p>
          </div>
          
          <div>
            <label className="form-label">Preferred Units</label>
            <p className="text-gray-900 dark:text-gray-100 capitalize">
              {profileData.settings?.units || 'Metric'}
            </p>
          </div>
        </div>
      </div>

      {/* App Settings */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">App Settings</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-gray-100">
                Theme Preference
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400 capitalize">
                {profileData.settings?.theme || 'Light'}
              </p>
            </div>
          </div>
          
          <div className="border-t border-gray-200 dark:border-gray-700 pt-4">
            <h4 className="font-medium text-gray-900 dark:text-gray-100 mb-3">
              Notification Preferences
            </h4>
            
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-gray-700 dark:text-gray-300">Workout Reminders</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  profileData.settings?.notifications?.workoutReminders
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                }`}>
                  {profileData.settings?.notifications?.workoutReminders ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-700 dark:text-gray-300">Nutrition Reminders</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  profileData.settings?.notifications?.nutritionReminders
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                }`}>
                  {profileData.settings?.notifications?.nutritionReminders ? 'Enabled' : 'Disabled'}
                </span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-700 dark:text-gray-300">Progress Reminders</span>
                <span className={`px-2 py-1 rounded text-xs font-medium ${
                  profileData.settings?.notifications?.progressReminders
                    ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                    : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
                }`}>
                  {profileData.settings?.notifications?.progressReminders ? 'Enabled' : 'Disabled'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Account Information */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Account Information</h3>
        
        <div className="space-y-4">
          <div>
            <label className="form-label">Member Since</label>
            <p className="text-gray-900 dark:text-gray-100">
              {new Date(profileData.createdAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
          </div>
          
          <div>
            <label className="form-label">Last Updated</label>
            <p className="text-gray-900 dark:text-gray-100">
              {new Date(profileData.updatedAt).toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Profile