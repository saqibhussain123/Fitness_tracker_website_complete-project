import React from 'react'
import { Calendar, Target, Award, Flame } from 'lucide-react'

const QuickStats = ({ stats = {} }) => {
  const {
    workoutsThisWeek = 0,
    streakDays = 0,
    totalWorkouts = 0,
    caloriesBurned = 0
  } = stats

  const statItems = [
    {
      label: 'This Week',
      value: workoutsThisWeek,
      icon: Calendar,
      color: 'text-blue-500'
    },
    {
      label: 'Current Streak',
      value: `${streakDays} days`,
      icon: Target,
      color: 'text-green-500'
    },
    {
      label: 'Total Workouts',
      value: totalWorkouts,
      icon: Award,
      color: 'text-purple-500'
    },
    {
      label: 'Calories Burned',
      value: caloriesBurned,
      icon: Flame,
      color: 'text-orange-500'
    }
  ]

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-4">Quick Stats</h3>
      <div className="grid grid-cols-2 gap-4">
        {statItems.map((item, index) => {
          const Icon = item.icon
          return (
            <div key={index} className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
              <Icon size={24} className={`mx-auto mb-2 ${item.color}`} />
              <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
                {item.value}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {item.label}
              </p>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export default QuickStats