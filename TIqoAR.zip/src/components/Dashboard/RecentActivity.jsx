import React from 'react'
import { Clock, Dumbbell, Apple, TrendingUp } from 'lucide-react'
import { formatDate, formatTime } from '../../utils/helpers'

const RecentActivity = ({ activities = [] }) => {
  const getActivityIcon = (type) => {
    switch (type) {
      case 'workout':
        return <Dumbbell size={16} className="text-blue-500" />
      case 'nutrition':
        return <Apple size={16} className="text-green-500" />
      case 'progress':
        return <TrendingUp size={16} className="text-purple-500" />
      default:
        return <Clock size={16} className="text-gray-500" />
    }
  }

  if (activities.length === 0) {
    return (
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
        <div className="text-center py-8">
          <Clock size={48} className="mx-auto text-gray-400 mb-4" />
          <p className="text-gray-500 dark:text-gray-400">No recent activity</p>
          <p className="text-sm text-gray-400 dark:text-gray-500">
            Start logging your workouts, meals, or progress to see activity here.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="card">
      <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
      <div className="space-y-4">
        {activities.map((activity, index) => (
          <div key={index} className="flex items-start space-x-3 pb-3 border-b border-gray-200 dark:border-gray-700 last:border-b-0">
            <div className="flex-shrink-0 mt-1">
              {getActivityIcon(activity.type)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-gray-900 dark:text-gray-100">
                {activity.title}
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {activity.description}
              </p>
              <p className="text-xs text-gray-400 dark:text-gray-500 mt-1">
                {formatDate(activity.date)} at {formatTime(activity.date)}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default RecentActivity