import React from 'react'

const DashboardCard = ({ title, value, subtitle, icon: Icon, color = 'primary', trend }) => {
  const colorClasses = {
    primary: 'bg-primary-50 dark:bg-primary-900 text-primary-600 dark:text-primary-400',
    green: 'bg-green-50 dark:bg-green-900 text-green-600 dark:text-green-400',
    blue: 'bg-blue-50 dark:bg-blue-900 text-blue-600 dark:text-blue-400',
    orange: 'bg-orange-50 dark:bg-orange-900 text-orange-600 dark:text-orange-400',
    red: 'bg-red-50 dark:bg-red-900 text-red-600 dark:text-red-400',
  }

  return (
    <div className="card">
      <div className="flex items-center">
        <div className={`p-3 rounded-lg ${colorClasses[color]}`}>
          <Icon size={24} />
        </div>
        <div className="ml-4 flex-1">
          <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400">
            {title}
          </h3>
          <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">
            {value}
          </p>
          {subtitle && (
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {subtitle}
            </p>
          )}
          {trend && (
            <div className={`text-sm font-medium ${
              trend.direction === 'up' 
                ? 'text-green-600 dark:text-green-400' 
                : trend.direction === 'down'
                ? 'text-red-600 dark:text-red-400'
                : 'text-gray-600 dark:text-gray-400'
            }`}>
              {trend.direction === 'up' ? '↗' : trend.direction === 'down' ? '↘' : '→'} {trend.value}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default DashboardCard