import React from 'react'
import { Bar } from 'react-chartjs-2'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
)

const WorkoutChart = ({ data = [], darkMode = false }) => {
  const chartData = {
    labels: data.map(item => item.day),
    datasets: [
      {
        label: 'Workouts',
        data: data.map(item => item.count),
        backgroundColor: 'rgba(93, 92, 222, 0.8)',
        borderColor: '#5D5CDE',
        borderWidth: 1,
      },
    ],
  }

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          color: darkMode ? '#e5e7eb' : '#374151',
        },
      },
      title: {
        display: true,
        text: 'Weekly Workout Frequency',
        color: darkMode ? '#e5e7eb' : '#374151',
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: {
          color: darkMode ? '#374151' : '#e5e7eb',
        },
        ticks: {
          color: darkMode ? '#e5e7eb' : '#374151',
        },
      },
      x: {
        grid: {
          color: darkMode ? '#374151' : '#e5e7eb',
        },
        ticks: {
          color: darkMode ? '#e5e7eb' : '#374151',
        },
      },
    },
  }

  if (data.length === 0) {
    return (
      <div className="chart-container flex items-center justify-center">
        <p className="text-gray-500 dark:text-gray-400">No workout data available</p>
      </div>
    )
  }

  return (
    <div className="chart-container">
      <Bar data={chartData} options={options} />
    </div>
  )
}

export default WorkoutChart