import React, { useState } from 'react'
import { Plus, Minus } from 'lucide-react'
import { WORKOUT_TYPES } from '../../utils/constants'

const WorkoutForm = ({ onSubmit, initialData = null, isLoading = false }) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    date: initialData?.date ? new Date(initialData.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
    duration: initialData?.duration || '',
    exercises: initialData?.exercises || [
      {
        name: '',
        type: 'strength',
        sets: [{ reps: '', weight: '', duration: '', distance: '' }],
        notes: ''
      }
    ],
    totalCaloriesBurned: initialData?.totalCaloriesBurned || '',
    notes: initialData?.notes || ''
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit(formData)
  }

  const addExercise = () => {
    setFormData(prev => ({
      ...prev,
      exercises: [
        ...prev.exercises,
        {
          name: '',
          type: 'strength',
          sets: [{ reps: '', weight: '', duration: '', distance: '' }],
          notes: ''
        }
      ]
    }))
  }

  const removeExercise = (index) => {
    if (formData.exercises.length > 1) {
      setFormData(prev => ({
        ...prev,
        exercises: prev.exercises.filter((_, i) => i !== index)
      }))
    }
  }

  const updateExercise = (exerciseIndex, field, value) => {
    setFormData(prev => ({
      ...prev,
      exercises: prev.exercises.map((exercise, i) => 
        i === exerciseIndex ? { ...exercise, [field]: value } : exercise
      )
    }))
  }

  const addSet = (exerciseIndex) => {
    setFormData(prev => ({
      ...prev,
      exercises: prev.exercises.map((exercise, i) => 
        i === exerciseIndex 
          ? { 
              ...exercise, 
              sets: [...exercise.sets, { reps: '', weight: '', duration: '', distance: '' }]
            }
          : exercise
      )
    }))
  }

  const removeSet = (exerciseIndex, setIndex) => {
    setFormData(prev => ({
      ...prev,
      exercises: prev.exercises.map((exercise, i) => 
        i === exerciseIndex 
          ? { 
              ...exercise, 
              sets: exercise.sets.filter((_, j) => j !== setIndex)
            }
          : exercise
      )
    }))
  }

  const updateSet = (exerciseIndex, setIndex, field, value) => {
    setFormData(prev => ({
      ...prev,
      exercises: prev.exercises.map((exercise, i) => 
        i === exerciseIndex 
          ? {
              ...exercise,
              sets: exercise.sets.map((set, j) => 
                j === setIndex ? { ...set, [field]: value } : set
              )
            }
          : exercise
      )
    }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Basic Info */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="form-label">Workout Name *</label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            className="input-field"
            required
            placeholder="e.g., Morning Run, Push Day"
          />
        </div>
        
        <div>
          <label className="form-label">Date *</label>
          <input
            type="date"
            value={formData.date}
            onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
            className="input-field"
            required
          />
        </div>
        
        <div>
          <label className="form-label">Duration (minutes) *</label>
          <input
            type="number"
            value={formData.duration}
            onChange={(e) => setFormData(prev => ({ ...prev, duration: e.target.value }))}
            className="input-field"
            required
            min="1"
            placeholder="45"
          />
        </div>
        
        <div>
          <label className="form-label">Calories Burned</label>
          <input
            type="number"
            value={formData.totalCaloriesBurned}
            onChange={(e) => setFormData(prev => ({ ...prev, totalCaloriesBurned: e.target.value }))}
            className="input-field"
            min="0"
            placeholder="300"
          />
        </div>
      </div>

      {/* Exercises */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">Exercises</h3>
          <button
            type="button"
            onClick={addExercise}
            className="btn-secondary flex items-center space-x-2"
          >
            <Plus size={16} />
            <span>Add Exercise</span>
          </button>
        </div>

        {formData.exercises.map((exercise, exerciseIndex) => (
          <div key={exerciseIndex} className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg mb-4">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-medium">Exercise {exerciseIndex + 1}</h4>
              {formData.exercises.length > 1 && (
                <button
                  type="button"
                  onClick={() => removeExercise(exerciseIndex)}
                  className="text-red-500 hover:text-red-700"
                >
                  <Minus size={16} />
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="form-label">Exercise Name *</label>
                <input
                  type="text"
                  value={exercise.name}
                  onChange={(e) => updateExercise(exerciseIndex, 'name', e.target.value)}
                  className="input-field"
                  required
                  placeholder="e.g., Push-ups, Bench Press"
                />
              </div>
              
              <div>
                <label className="form-label">Type</label>
                <select
                  value={exercise.type}
                  onChange={(e) => updateExercise(exerciseIndex, 'type', e.target.value)}
                  className="input-field"
                >
                  {WORKOUT_TYPES.map(type => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Sets */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-2">
                <label className="form-label mb-0">Sets</label>
                <button
                  type="button"
                  onClick={() => addSet(exerciseIndex)}
                  className="text-primary-500 hover:text-primary-600 text-sm"
                >
                  + Add Set
                </button>
              </div>

              {exercise.sets.map((set, setIndex) => (
                <div key={setIndex} className="flex items-center space-x-2 mb-2">
                  <span className="text-sm font-medium w-8">{setIndex + 1}.</span>
                  
                  <input
                    type="number"
                    value={set.reps}
                    onChange={(e) => updateSet(exerciseIndex, setIndex, 'reps', e.target.value)}
                    className="input-field flex-1"
                    placeholder="Reps"
                    min="0"
                  />
                  
                  <input
                    type="number"
                    value={set.weight}
                    onChange={(e) => updateSet(exerciseIndex, setIndex, 'weight', e.target.value)}
                    className="input-field flex-1"
                    placeholder="Weight (kg)"
                    min="0"
                    step="0.5"
                  />
                  
                  <input
                    type="number"
                    value={set.duration}
                    onChange={(e) => updateSet(exerciseIndex, setIndex, 'duration', e.target.value)}
                    className="input-field flex-1"
                    placeholder="Duration (min)"
                    min="0"
                  />
                  
                  <input
                    type="number"
                    value={set.distance}
                    onChange={(e) => updateSet(exerciseIndex, setIndex, 'distance', e.target.value)}
                    className="input-field flex-1"
                    placeholder="Distance (km)"
                    min="0"
                    step="0.1"
                  />
                  
                  {exercise.sets.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeSet(exerciseIndex, setIndex)}
                      className="text-red-500 hover:text-red-700"
                    >
                      <Minus size={16} />
                    </button>
                  )}
                </div>
              ))}
            </div>

            <div>
              <label className="form-label">Exercise Notes</label>
              <textarea
                value={exercise.notes}
                onChange={(e) => updateExercise(exerciseIndex, 'notes', e.target.value)}
                className="input-field"
                rows="2"
                placeholder="Any notes about this exercise..."
              />
            </div>
          </div>
        ))}
      </div>

      {/* Workout Notes */}
      <div>
        <label className="form-label">Workout Notes</label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
          className="input-field"
          rows="3"
          placeholder="How did the workout feel? Any achievements or observations..."
        />
      </div>

      {/* Submit Button */}
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={isLoading}
          className="btn-primary"
        >
          {isLoading ? 'Saving...' : initialData ? 'Update Workout' : 'Save Workout'}
        </button>
      </div>
    </form>
  )
}

export default WorkoutForm