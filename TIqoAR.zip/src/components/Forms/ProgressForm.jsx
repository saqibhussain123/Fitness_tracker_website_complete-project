import React, { useState } from 'react'
import { MOOD_OPTIONS } from '../../utils/constants'

const ProgressForm = ({ onSubmit, initialData = null, isLoading = false }) => {
  const [formData, setFormData] = useState({
    date: initialData?.date ? new Date(initialData.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
    weight: initialData?.weight || '',
    bodyMeasurements: initialData?.bodyMeasurements || {
      chest: '',
      waist: '',
      hips: '',
      biceps: '',
      thighs: '',
      neck: ''
    },
    bodyFatPercentage: initialData?.bodyFatPercentage || '',
    muscleMass: initialData?.muscleMass || '',
    mood: initialData?.mood || 'average',
    energyLevel: initialData?.energyLevel || 5,
    sleepHours: initialData?.sleepHours || '',
    notes: initialData?.notes || ''
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit(formData)
  }

  const handleMeasurementChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      bodyMeasurements: {
        ...prev.bodyMeasurements,
        [field]: value
      }
    }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Date and Weight */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="form-label">Date *</label>
          <input
            type="date"
            value={formData.date}
            onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
            className="input-field"
            required
          />
        </div>
        
        <div>
          <label className="form-label">Weight (kg) *</label>
          <input
            type="number"
            value={formData.weight}
            onChange={(e) => setFormData(prev => ({ ...prev, weight: e.target.value }))}
            className="input-field"
            required
            min="30"
            max="300"
            step="0.1"
            placeholder="70.5"
          />
        </div>
      </div>

      {/* Body Measurements */}
      <div>
        <h3 className="text-lg font-medium mb-4">Body Measurements (cm)</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Chest</label>
            <input
              type="number"
              value={formData.bodyMeasurements.chest}
              onChange={(e) => handleMeasurementChange('chest', e.target.value)}
              className="input-field"
              min="50"
              max="200"
              step="0.5"
              placeholder="95"
            />
          </div>
          
          <div>
            <label className="form-label">Waist</label>
            <input
              type="number"
              value={formData.bodyMeasurements.waist}
              onChange={(e) => handleMeasurementChange('waist', e.target.value)}
              className="input-field"
              min="50"
              max="200"
              step="0.5"
              placeholder="85"
            />
          </div>
          
          <div>
            <label className="form-label">Hips</label>
            <input
              type="number"
              value={formData.bodyMeasurements.hips}
              onChange={(e) => handleMeasurementChange('hips', e.target.value)}
              className="input-field"
              min="50"
              max="200"
              step="0.5"
              placeholder="90"
            />
          </div>
          
          <div>
            <label className="form-label">Biceps</label>
            <input
              type="number"
              value={formData.bodyMeasurements.biceps}
              onChange={(e) => handleMeasurementChange('biceps', e.target.value)}
              className="input-field"
              min="20"
              max="60"
              step="0.5"
              placeholder="35"
            />
          </div>
          
          <div>
            <label className="form-label">Thighs</label>
            <input
              type="number"
              value={formData.bodyMeasurements.thighs}
              onChange={(e) => handleMeasurementChange('thighs', e.target.value)}
              className="input-field"
              min="30"
              max="100"
              step="0.5"
              placeholder="55"
            />
          </div>
          
          <div>
            <label className="form-label">Neck</label>
            <input
              type="number"
              value={formData.bodyMeasurements.neck}
              onChange={(e) => handleMeasurementChange('neck', e.target.value)}
              className="input-field"
              min="25"
              max="60"
              step="0.5"
              placeholder="38"
            />
          </div>
        </div>
      </div>

      {/* Body Composition */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="form-label">Body Fat Percentage (%)</label>
          <input
            type="number"
            value={formData.bodyFatPercentage}
            onChange={(e) => setFormData(prev => ({ ...prev, bodyFatPercentage: e.target.value }))}
            className="input-field"
            min="5"
            max="50"
            step="0.1"
            placeholder="15.5"
          />
        </div>
        
        <div>
          <label className="form-label">Muscle Mass (kg)</label>
          <input
            type="number"
            value={formData.muscleMass}
            onChange={(e) => setFormData(prev => ({ ...prev, muscleMass: e.target.value }))}
            className="input-field"
            min="20"
            max="100"
            step="0.1"
            placeholder="45.2"
          />
        </div>
      </div>

      {/* Wellness Metrics */}
      <div>
        <h3 className="text-lg font-medium mb-4">Wellness Metrics</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Mood</label>
            <select
              value={formData.mood}
              onChange={(e) => setFormData(prev => ({ ...prev, mood: e.target.value }))}
              className="input-field"
            >
              {MOOD_OPTIONS.map(mood => (
                <option key={mood.value} value={mood.value}>
                  {mood.emoji} {mood.label}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="form-label">Energy Level (1-10)</label>
            <input
              type="range"
              value={formData.energyLevel}
              onChange={(e) => setFormData(prev => ({ ...prev, energyLevel: e.target.value }))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
              min="1"
              max="10"
            />
            <div className="flex justify-between text-sm text-gray-500 dark:text-gray-400 mt-1">
              <span>Low</span>
              <span className="font-medium">{formData.energyLevel}</span>
              <span>High</span>
            </div>
          </div>
          
          <div>
            <label className="form-label">Sleep Hours</label>
            <input
              type="number"
              value={formData.sleepHours}
              onChange={(e) => setFormData(prev => ({ ...prev, sleepHours: e.target.value }))}
              className="input-field"
              min="0"
              max="24"
              step="0.5"
              placeholder="8"
            />
          </div>
        </div>
      </div>

      {/* Notes */}
      <div>
        <label className="form-label">Notes</label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
          className="input-field"
          rows="4"
          placeholder="How are you feeling today? Any observations about your progress, changes in energy, strength, or overall well-being..."
        />
      </div>

      {/* Submit Button */}
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={isLoading}
          className="btn-primary"
        >
          {isLoading ? 'Saving...' : initialData ? 'Update Progress' : 'Save Progress'}
        </button>
      </div>
    </form>
  )
}

export default ProgressForm