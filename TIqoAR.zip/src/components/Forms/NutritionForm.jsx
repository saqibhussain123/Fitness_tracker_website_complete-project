import React, { useState } from 'react'
import { Plus, Minus } from 'lucide-react'
import { MEAL_TYPES } from '../../utils/constants'

const NutritionForm = ({ onSubmit, initialData = null, isLoading = false }) => {
  const [formData, setFormData] = useState({
    date: initialData?.date ? new Date(initialData.date).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
    meals: initialData?.meals || {
      breakfast: [],
      lunch: [],
      dinner: [],
      snacks: []
    },
    waterIntake: initialData?.waterIntake || '',
    notes: initialData?.notes || ''
  })

  const [newFoodItem, setNewFoodItem] = useState({
    name: '',
    quantity: '',
    unit: 'grams',
    calories: '',
    macros: {
      protein: '',
      carbs: '',
      fat: '',
      fiber: '',
      sugar: ''
    }
  })

  const [selectedMeal, setSelectedMeal] = useState('breakfast')

  const calculateTotals = () => {
    let totalCalories = 0
    let totalMacros = { protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0 }

    Object.values(formData.meals).forEach(meal => {
      meal.forEach(item => {
        totalCalories += Number(item.calories) || 0
        Object.keys(totalMacros).forEach(macro => {
          totalMacros[macro] += Number(item.macros[macro]) || 0
        })
      })
    })

    return { totalCalories, totalMacros }
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const { totalCalories, totalMacros } = calculateTotals()
    
    const submitData = {
      ...formData,
      totalCalories,
      totalMacros
    }
    
    onSubmit(submitData)
  }

  const addFoodItem = () => {
    if (!newFoodItem.name || !newFoodItem.calories) return

    setFormData(prev => ({
      ...prev,
      meals: {
        ...prev.meals,
        [selectedMeal]: [
          ...prev.meals[selectedMeal],
          { ...newFoodItem }
        ]
      }
    }))

    setNewFoodItem({
      name: '',
      quantity: '',
      unit: 'grams',
      calories: '',
      macros: {
        protein: '',
        carbs: '',
        fat: '',
        fiber: '',
        sugar: ''
      }
    })
  }

  const removeFoodItem = (mealType, index) => {
    setFormData(prev => ({
      ...prev,
      meals: {
        ...prev.meals,
        [mealType]: prev.meals[mealType].filter((_, i) => i !== index)
      }
    }))
  }

  const { totalCalories, totalMacros } = calculateTotals()

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Date */}
      <div>
        <label className="form-label">Date *</label>
        <input
          type="date"
          value={formData.date}
          onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
          className="input-field max-w-xs"
          required
        />
      </div>

      {/* Add Food Item */}
      <div className="card bg-gray-50 dark:bg-gray-700">
        <h3 className="text-lg font-medium mb-4">Add Food Item</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="form-label">Meal Type</label>
            <select
              value={selectedMeal}
              onChange={(e) => setSelectedMeal(e.target.value)}
              className="input-field"
            >
              {MEAL_TYPES.map(meal => (
                <option key={meal} value={meal}>
                  {meal.charAt(0).toUpperCase() + meal.slice(1)}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="form-label">Food Name *</label>
            <input
              type="text"
              value={newFoodItem.name}
              onChange={(e) => setNewFoodItem(prev => ({ ...prev, name: e.target.value }))}
              className="input-field"
              placeholder="e.g., Chicken Breast"
            />
          </div>
          
          <div>
            <label className="form-label">Quantity *</label>
            <input
              type="number"
              value={newFoodItem.quantity}
              onChange={(e) => setNewFoodItem(prev => ({ ...prev, quantity: e.target.value }))}
              className="input-field"
              placeholder="100"
              min="0"
            />
          </div>
          
          <div>
            <label className="form-label">Unit</label>
            <select
              value={newFoodItem.unit}
              onChange={(e) => setNewFoodItem(prev => ({ ...prev, unit: e.target.value }))}
              className="input-field"
            >
              <option value="grams">Grams</option>
              <option value="cups">Cups</option>
              <option value="pieces">Pieces</option>
              <option value="slices">Slices</option>
              <option value="tablespoons">Tablespoons</option>
              <option value="teaspoons">Teaspoons</option>
            </select>
          </div>
          
          <div>
            <label className="form-label">Calories *</label>
            <input
              type="number"
              value={newFoodItem.calories}
              onChange={(e) => setNewFoodItem(prev => ({ ...prev, calories: e.target.value }))}
              className="input-field"
              placeholder="250"
              min="0"
            />
          </div>
        </div>

        {/* Macros */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
          <div>
            <label className="form-label">Protein (g)</label>
            <input
              type="number"
              value={newFoodItem.macros.protein}
              onChange={(e) => setNewFoodItem(prev => ({ 
                ...prev, 
                macros: { ...prev.macros, protein: e.target.value }
              }))}
              className="input-field"
              placeholder="25"
              min="0"
            />
          </div>
          
          <div>
            <label className="form-label">Carbs (g)</label>
            <input
              type="number"
              value={newFoodItem.macros.carbs}
              onChange={(e) => setNewFoodItem(prev => ({ 
                ...prev, 
                macros: { ...prev.macros, carbs: e.target.value }
              }))}
              className="input-field"
              placeholder="10"
              min="0"
            />
          </div>
          
          <div>
            <label className="form-label">Fat (g)</label>
            <input
              type="number"
              value={newFoodItem.macros.fat}
              onChange={(e) => setNewFoodItem(prev => ({ 
                ...prev, 
                macros: { ...prev.macros, fat: e.target.value }
              }))}
              className="input-field"
              placeholder="5"
              min="0"
            />
          </div>
          
          <div>
            <label className="form-label">Fiber (g)</label>
            <input
              type="number"
              value={newFoodItem.macros.fiber}
              onChange={(e) => setNewFoodItem(prev => ({ 
                ...prev, 
                macros: { ...prev.macros, fiber: e.target.value }
              }))}
              className="input-field"
              placeholder="2"
              min="0"
            />
          </div>
          
          <div>
            <label className="form-label">Sugar (g)</label>
            <input
              type="number"
              value={newFoodItem.macros.sugar}
              onChange={(e) => setNewFoodItem(prev => ({ 
                ...prev, 
                macros: { ...prev.macros, sugar: e.target.value }
              }))}
              className="input-field"
              placeholder="1"
              min="0"
            />
          </div>
        </div>

        <button
          type="button"
          onClick={addFoodItem}
          className="btn-primary"
          disabled={!newFoodItem.name || !newFoodItem.calories}
        >
          Add to {selectedMeal.charAt(0).toUpperCase() + selectedMeal.slice(1)}
        </button>
      </div>

      {/* Meals Display */}
      <div className="space-y-4">
        {MEAL_TYPES.map(mealType => (
          <div key={mealType} className="card">
            <h3 className="text-lg font-medium mb-3 capitalize">
              {mealType} ({formData.meals[mealType].length} items)
            </h3>
            
            {formData.meals[mealType].length === 0 ? (
              <p className="text-gray-500 dark:text-gray-400 text-center py-4">
                No items added to {mealType}
              </p>
            ) : (
              <div className="space-y-2">
                {formData.meals[mealType].map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <div className="flex-1">
                      <span className="font-medium">{item.name}</span>
                      <span className="text-gray-500 dark:text-gray-400 ml-2">
                        {item.quantity} {item.unit}
                      </span>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        {item.calories} cal • P: {item.macros.protein}g • C: {item.macros.carbs}g • F: {item.macros.fat}g
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => removeFoodItem(mealType, index)}
                      className="text-red-500 hover:text-red-700 ml-4"
                    >
                      <Minus size={20} />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Water Intake */}
      <div>
        <label className="form-label">Water Intake (liters)</label>
        <input
          type="number"
          value={formData.waterIntake}
          onChange={(e) => setFormData(prev => ({ ...prev, waterIntake: e.target.value }))}
          className="input-field max-w-xs"
          placeholder="2.5"
          min="0"
          step="0.1"
        />
      </div>

      {/* Notes */}
      <div>
        <label className="form-label">Notes</label>
        <textarea
          value={formData.notes}
          onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
          className="input-field"
          rows="3"
          placeholder="How did you feel today? Any observations about your nutrition..."
        />
      </div>

      {/* Daily Summary */}
      <div className="card bg-primary-50 dark:bg-primary-900">
        <h3 className="text-lg font-medium mb-3">Daily Summary</h3>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 text-center">
          <div>
            <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
              {totalCalories}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Calories</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
              {totalMacros.protein}g
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Protein</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
              {totalMacros.carbs}g
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Carbs</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
              {totalMacros.fat}g
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Fat</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
              {totalMacros.fiber}g
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Fiber</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-primary-600 dark:text-primary-400">
              {formData.waterIntake || 0}L
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Water</p>
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={isLoading}
          className="btn-primary"
        >
          {isLoading ? 'Saving...' : initialData ? 'Update Nutrition Log' : 'Save Nutrition Log'}
        </button>
      </div>
    </form>
  )
}

export default NutritionForm