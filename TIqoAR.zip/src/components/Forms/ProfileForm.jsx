import React, { useState } from 'react'
import { GENDER_OPTIONS, ACTIVITY_LEVELS, FITNESS_GOALS, UNITS } from '../../utils/constants'
import { calculateBMI, getBMICategory } from '../../utils/helpers'

const ProfileForm = ({ onSubmit, initialData = null, isLoading = false }) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    email: initialData?.email || '',
    profile: {
      age: initialData?.profile?.age || '',
      gender: initialData?.profile?.gender || 'other',
      height: initialData?.profile?.height || '',
      currentWeight: initialData?.profile?.currentWeight || '',
      targetWeight: initialData?.profile?.targetWeight || '',
      activityLevel: initialData?.profile?.activityLevel || 'moderate',
      fitnessGoal: initialData?.profile?.fitnessGoal || 'maintain_weight'
    },
    settings: {
      units: initialData?.settings?.units || 'metric',
      theme: initialData?.settings?.theme || 'light',
      notifications: {
        workoutReminders: initialData?.settings?.notifications?.workoutReminders ?? true,
        nutritionReminders: initialData?.settings?.notifications?.nutritionReminders ?? true,
        progressReminders: initialData?.settings?.notifications?.progressReminders ?? true
      }
    }
  })

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit(formData)
  }

  const handleProfileChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        [field]: value
      }
    }))
  }

  const handleSettingsChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        [field]: value
      }
    }))
  }

  const handleNotificationChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      settings: {
        ...prev.settings,
        notifications: {
          ...prev.settings.notifications,
          [field]: value
        }
      }
    }))
  }

  const bmi = calculateBMI(formData.profile.currentWeight, formData.profile.height)
  const bmiCategory = getBMICategory(bmi)

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Basic Information */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Basic Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="form-label">Full Name *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              className="input-field"
              required
              placeholder="John Doe"
            />
          </div>
          
          <div>
            <label className="form-label">Email Address *</label>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              className="input-field"
              required
              placeholder="john@example.com"
            />
          </div>
        </div>
      </div>

      {/* Physical Information */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Physical Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <label className="form-label">Age</label>
            <input
              type="number"
              value={formData.profile.age}
              onChange={(e) => handleProfileChange('age', e.target.value)}
              className="input-field"
              min="13"
              max="120"
              placeholder="25"
            />
          </div>
          
          <div>
            <label className="form-label">Gender</label>
            <select
              value={formData.profile.gender}
              onChange={(e) => handleProfileChange('gender', e.target.value)}
              className="input-field"
            >
              {GENDER_OPTIONS.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="form-label">Height (cm)</label>
            <input
              type="number"
              value={formData.profile.height}
              onChange={(e) => handleProfileChange('height', e.target.value)}
              className="input-field"
              min="100"
              max="250"
              placeholder="175"
            />
          </div>
          
          <div>
            <label className="form-label">Current Weight (kg)</label>
            <input
              type="number"
              value={formData.profile.currentWeight}
              onChange={(e) => handleProfileChange('currentWeight', e.target.value)}
              className="input-field"
              min="30"
              max="300"
              step="0.1"
              placeholder="70"
            />
          </div>
          
          <div>
            <label className="form-label">Target Weight (kg)</label>
            <input
              type="number"
              value={formData.profile.targetWeight}
              onChange={(e) => handleProfileChange('targetWeight', e.target.value)}
              className="input-field"
              min="30"
              max="300"
              step="0.1"
              placeholder="65"
            />
          </div>

          {/* BMI Display */}
          {bmi > 0 && (
            <div className="md:col-span-1">
              <label className="form-label">BMI</label>
              <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <span className="text-lg font-semibold">{bmi}</span>
                <span className="text-sm text-gray-600 dark:text-gray-400 ml-2">
                  ({bmiCategory})
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Fitness Information */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Fitness Information</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="form-label">Activity Level</label>
            <select
              value={formData.profile.activityLevel}
              onChange={(e) => handleProfileChange('activityLevel', e.target.value)}
              className="input-field"
            >
              {ACTIVITY_LEVELS.map(level => (
                <option key={level.value} value={level.value}>
                  {level.label}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="form-label">Fitness Goal</label>
            <select
              value={formData.profile.fitnessGoal}
              onChange={(e) => handleProfileChange('fitnessGoal', e.target.value)}
              className="input-field"
            >
              {FITNESS_GOALS.map(goal => (
                <option key={goal.value} value={goal.value}>
                  {goal.label}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* App Settings */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">App Settings</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="form-label">Units</label>
            <select
              value={formData.settings.units}
              onChange={(e) => handleSettingsChange('units', e.target.value)}
              className="input-field"
            >
              {UNITS.map(unit => (
                <option key={unit.value} value={unit.value}>
                  {unit.label}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <label className="form-label">Theme</label>
            <select
              value={formData.settings.theme}
              onChange={(e) => handleSettingsChange('theme', e.target.value)}
              className="input-field"
            >
              <option value="light">Light</option>
              <option value="dark">Dark</option>
            </select>
          </div>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="card">
        <h3 className="text-lg font-semibold mb-4">Notification Preferences</h3>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium text-gray-900 dark:text-gray-100">
                Workout Reminders
              </label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get reminded to log your workouts
              </p>
            </div>
            <input
              type="checkbox"
              checked={formData.settings.notifications.workoutReminders}
              onChange={(e) => handleNotificationChange('workoutReminders', e.target.checked)}
              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium text-gray-900 dark:text-gray-100">
                Nutrition Reminders
              </label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get reminded to log your meals
              </p>
            </div>
            <input
              type="checkbox"
              checked={formData.settings.notifications.nutritionReminders}
              onChange={(e) => handleNotificationChange('nutritionReminders', e.target.checked)}
              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <label className="font-medium text-gray-900 dark:text-gray-100">
                Progress Reminders
              </label>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get reminded to track your progress
              </p>
            </div>
            <input
              type="checkbox"
              checked={formData.settings.notifications.progressReminders}
              onChange={(e) => handleNotificationChange('progressReminders', e.target.checked)}
              className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
            />
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={isLoading}
          className="btn-primary"
        >
          {isLoading ? 'Saving...' : 'Save Profile'}
        </button>
      </div>
    </form>
  )
}

export default ProfileForm