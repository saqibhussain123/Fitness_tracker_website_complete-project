import React, { useState } from 'react'
import { Download, FileText, Image } from 'lucide-react'
import { exportToCSV } from '../../utils/helpers'
import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'
import toast from 'react-hot-toast'

const ExportButton = ({ data, filename, type = 'csv', elementId = null }) => {
  const [isExporting, setIsExporting] = useState(false)

  const handleExport = async () => {
    setIsExporting(true)
    
    try {
      if (type === 'csv') {
        exportToCSV(data, filename)
        toast.success('Data exported to CSV successfully!')
      } else if (type === 'pdf') {
        await exportToPDF()
        toast.success('Data exported to PDF successfully!')
      }
    } catch (error) {
      console.error('Export error:', error)
      toast.error('Failed to export data')
    } finally {
      setIsExporting(false)
    }
  }

  const exportToPDF = async () => {
    if (!elementId) {
      throw new Error('Element ID required for PDF export')
    }

    const element = document.getElementById(elementId)
    if (!element) {
      throw new Error('Element not found')
    }

    const canvas = await html2canvas(element)
    const imgData = canvas.toDataURL('image/png')
    
    const pdf = new jsPDF()
    const imgWidth = 210
    const pageHeight = 295
    const imgHeight = (canvas.height * imgWidth) / canvas.width
    let heightLeft = imgHeight

    let position = 0

    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
    heightLeft -= pageHeight

    while (heightLeft >= 0) {
      position = heightLeft - imgHeight
      pdf.addPage()
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight)
      heightLeft -= pageHeight
    }

    pdf.save(filename)
  }

  const getIcon = () => {
    switch (type) {
      case 'pdf':
        return <FileText size={16} />
      case 'image':
        return <Image size={16} />
      default:
        return <Download size={16} />
    }
  }

  return (
    <button
      onClick={handleExport}
      disabled={isExporting}
      className="btn-secondary flex items-center space-x-2"
    >
      {getIcon()}
      <span>
        {isExporting ? 'Exporting...' : `Export ${type.toUpperCase()}`}
      </span>
    </button>
  )
}

export default ExportButton