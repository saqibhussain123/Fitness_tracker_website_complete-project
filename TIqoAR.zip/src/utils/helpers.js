export const formatDate = (date, format = 'medium') => {
  if (!date) return ''
  
  const d = new Date(date)
  const options = {
    short: { month: 'short', day: 'numeric' },
    medium: { month: 'short', day: 'numeric', year: 'numeric' },
    long: { month: 'long', day: 'numeric', year: 'numeric' },
    full: { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' }
  }
  
  return d.toLocaleDateString('en-US', options[format] || options.medium)
}

export const formatTime = (date) => {
  if (!date) return ''
  return new Date(date).toLocaleTimeString('en-US', { 
    hour: '2-digit', 
    minute: '2-digit' 
  })
}

export const formatDuration = (minutes) => {
  if (!minutes) return '0 min'
  
  const hours = Math.floor(minutes / 60)
  const mins = minutes % 60
  
  if (hours > 0) {
    return `${hours}h ${mins}m`
  }
  return `${mins} min`
}

export const formatWeight = (weight, unit = 'metric') => {
  if (!weight) return '0'
  
  if (unit === 'imperial') {
    const lbs = (weight * 2.20462).toFixed(1)
    return `${lbs} lbs`
  }
  
  return `${weight} kg`
}

export const formatHeight = (height, unit = 'metric') => {
  if (!height) return '0'
  
  if (unit === 'imperial') {
    const totalInches = height * 0.393701
    const feet = Math.floor(totalInches / 12)
    const inches = Math.round(totalInches % 12)
    return `${feet}'${inches}"`
  }
  
  return `${height} cm`
}

export const calculateBMI = (weight, height) => {
  if (!weight || !height) return 0
  
  const heightInMeters = height / 100
  const bmi = weight / (heightInMeters * heightInMeters)
  return Math.round(bmi * 10) / 10
}

export const getBMICategory = (bmi) => {
  if (bmi < 18.5) return 'Underweight'
  if (bmi < 25) return 'Normal'
  if (bmi < 30) return 'Overweight'
  return 'Obese'
}

export const calculateCalorieGoal = (profile) => {
  if (!profile) return 2000
  
  const { age, gender, height, currentWeight, activityLevel } = profile
  
  if (!age || !height || !currentWeight) return 2000
  
  // Harris-Benedict equation
  let bmr
  if (gender === 'male') {
    bmr = 88.362 + (13.397 * currentWeight) + (4.799 * height) - (5.677 * age)
  } else {
    bmr = 447.593 + (9.247 * currentWeight) + (3.098 * height) - (4.330 * age)
  }
  
  // Activity multipliers
  const multipliers = {
    sedentary: 1.2,
    light: 1.375,
    moderate: 1.55,
    active: 1.725,
    very_active: 1.9
  }
  
  const tdee = bmr * (multipliers[activityLevel] || multipliers.moderate)
  return Math.round(tdee)
}

export const exportToCSV = (data, filename = 'fitpulse_data.csv') => {
  if (!data || data.length === 0) return
  
  const headers = Object.keys(data[0])
  const csvContent = [
    headers.join(','),
    ...data.map(row => headers.map(header => 
      JSON.stringify(row[header] || '')
    ).join(','))
  ].join('\n')
  
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  link.href = URL.createObjectURL(blob)
  link.download = filename
  link.click()
}

export const debounce = (func, wait) => {
  let timeout
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout)
      func(...args)
    }
    clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

export const truncateText = (text, maxLength = 100) => {
  if (!text) return ''
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength) + '...'
}

export const generateId = () => {
  return Date.now().toString(36) + Math.random().toString(36).substr(2)
}

export const validateEmail = (email) => {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return re.test(email)
}

export const validatePassword = (password) => {
  return password && password.length >= 6
}

export const getErrorMessage = (error) => {
  if (error.response?.data?.message) {
    return error.response.data.message
  }
  if (error.response?.data?.errors) {
    return error.response.data.errors[0]?.msg || 'Validation error'
  }
  return error.message || 'An unexpected error occurred'
}

export const sortByDate = (array, dateField = 'date', ascending = false) => {
  return [...array].sort((a, b) => {
    const dateA = new Date(a[dateField])
    const dateB = new Date(b[dateField])
    return ascending ? dateA - dateB : dateB - dateA
  })
}

export const groupByDate = (array, dateField = 'date') => {
  return array.reduce((groups, item) => {
    const date = formatDate(item[dateField], 'short')
    if (!groups[date]) {
      groups[date] = []
    }
    groups[date].push(item)
    return groups
  }, {})
}

export const calculatePercentageChange = (current, previous) => {
  if (!previous || previous === 0) return 0
  return Math.round(((current - previous) / previous) * 100)
}