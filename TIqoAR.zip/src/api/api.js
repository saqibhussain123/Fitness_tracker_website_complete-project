import axios from 'axios'

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor to handle common errors
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// API functions
export const authAPI = {
  login: (email, password) => api.post('/auth/login', { email, password }),
  register: (name, email, password) => api.post('/auth/register', { name, email, password }),
  getMe: () => api.get('/auth/me'),
}

export const userAPI = {
  getProfile: () => api.get('/users/profile'),
  updateProfile: (data) => api.put('/users/profile', data),
  updateSettings: (settings) => api.put('/users/settings', { settings }),
  deleteAccount: () => api.delete('/users/account'),
}

export const workoutAPI = {
  create: (workout) => api.post('/workouts', workout),
  getAll: (params) => api.get('/workouts', { params }),
  getOne: (id) => api.get(`/workouts/${id}`),
  update: (id, workout) => api.put(`/workouts/${id}`, workout),
  delete: (id) => api.delete(`/workouts/${id}`),
  getStats: () => api.get('/workouts/stats'),
}

export const nutritionAPI = {
  create: (nutrition) => api.post('/nutrition', nutrition),
  getAll: (params) => api.get('/nutrition', { params }),
  getOne: (id) => api.get(`/nutrition/${id}`),
  update: (id, nutrition) => api.put(`/nutrition/${id}`, nutrition),
  delete: (id) => api.delete(`/nutrition/${id}`),
  getStats: () => api.get('/nutrition/stats'),
}

export const progressAPI = {
  create: (progress) => api.post('/progress', progress),
  getAll: (params) => api.get('/progress', { params }),
  getOne: (id) => api.get(`/progress/${id}`),
  update: (id, progress) => api.put(`/progress/${id}`, progress),
  delete: (id) => api.delete(`/progress/${id}`),
  getStats: () => api.get('/progress/stats'),
}

export const feedbackAPI = {
  create: (feedback) => api.post('/feedback', feedback),
  getAll: (params) => api.get('/feedback', { params }),
  getOne: (id) => api.get(`/feedback/${id}`),
  update: (id, feedback) => api.put(`/feedback/${id}`, feedback),
  delete: (id) => api.delete(`/feedback/${id}`),
}