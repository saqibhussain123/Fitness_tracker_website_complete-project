const mongoose = require('mongoose');

const progressSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },
  weight: {
    type: Number, // in kg
    required: true
  },
  bodyMeasurements: {
    chest: Number, // in cm
    waist: Number,
    hips: Number,
    biceps: Number,
    thighs: Number,
    neck: Number
  },
  bodyFatPercentage: Number,
  muscleMass: Number,
  photos: [{
    url: String,
    type: {
      type: String,
      enum: ['front', 'side', 'back'],
      default: 'front'
    }
  }],
  mood: {
    type: String,
    enum: ['excellent', 'good', 'average', 'poor', 'terrible'],
    default: 'average'
  },
  energyLevel: {
    type: Number,
    min: 1,
    max: 10,
    default: 5
  },
  sleepHours: {
    type: Number,
    min: 0,
    max: 24,
    default: 8
  },
  notes: String
}, {
  timestamps: true
});

module.exports = mongoose.model('Progress', progressSchema);