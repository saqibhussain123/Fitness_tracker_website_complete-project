const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Workout = require('../models/Workout');
const Nutrition = require('../models/Nutrition');
const Progress = require('../models/Progress');
require('dotenv').config();

const connectDB = async () => {
  try {
    const mongoURI = process.env.MONGODB_URI || 'mongodb://localhost:27017/fitpulse';
    await mongoose.connect(mongoURI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB Connected');
  } catch (error) {
    console.error('MongoDB connection error:', error);
    process.exit(1);
  }
};

const seedData = async () => {
  try {
    await connectDB();

    // Clear existing data
    await User.deleteMany({});
    await Workout.deleteMany({});
    await Nutrition.deleteMany({});
    await Progress.deleteMany({});

    console.log('🗑️ Cleared existing data');

    // Create sample users
    const users = [
      {
        name: 'John Doe',
        email: 'john@example.com',
        password: await bcrypt.hash('password123', 10),
        profile: {
          age: 28,
          gender: 'male',
          height: 175,
          currentWeight: 75,
          targetWeight: 70,
          activityLevel: 'moderate',
          fitnessGoal: 'lose_weight'
        }
      },
      {
        name: 'Jane Smith',
        email: 'jane@example.com',
        password: await bcrypt.hash('password123', 10),
        profile: {
          age: 25,
          gender: 'female',
          height: 165,
          currentWeight: 60,
          targetWeight: 65,
          activityLevel: 'active',
          fitnessGoal: 'build_muscle'
        }
      }
    ];

    const createdUsers = await User.insertMany(users);
    console.log('👥 Created sample users');

    // Create sample workouts
    const workouts = [
      {
        user: createdUsers[0]._id,
        name: 'Morning Run',
        date: new Date('2024-01-15'),
        duration: 30,
        exercises: [
          {
            name: 'Running',
            type: 'cardio',
            sets: [{
              duration: 30,
              distance: 5
            }]
          }
        ],
        totalCaloriesBurned: 300
      },
      {
        user: createdUsers[0]._id,
        name: 'Strength Training',
        date: new Date('2024-01-16'),
        duration: 45,
        exercises: [
          {
            name: 'Push-ups',
            type: 'strength',
            sets: [
              { reps: 15, weight: 0 },
              { reps: 12, weight: 0 },
              { reps: 10, weight: 0 }
            ]
          },
          {
            name: 'Bench Press',
            type: 'strength',
            sets: [
              { reps: 10, weight: 60 },
              { reps: 8, weight: 65 },
              { reps: 6, weight: 70 }
            ]
          }
        ],
        totalCaloriesBurned: 250
      }
    ];

    await Workout.insertMany(workouts);
    console.log('💪 Created sample workouts');

    // Create sample nutrition logs
    const nutritionLogs = [
      {
        user: createdUsers[0]._id,
        date: new Date('2024-01-15'),
        meals: {
          breakfast: [
            {
              name: 'Oatmeal',
              quantity: 100,
              unit: 'grams',
              calories: 350,
              macros: { protein: 12, carbs: 60, fat: 6 }
            }
          ],
          lunch: [
            {
              name: 'Chicken Salad',
              quantity: 200,
              unit: 'grams',
              calories: 250,
              macros: { protein: 30, carbs: 10, fat: 8 }
            }
          ],
          dinner: [
            {
              name: 'Salmon with Rice',
              quantity: 250,
              unit: 'grams',
              calories: 400,
              macros: { protein: 35, carbs: 45, fat: 12 }
            }
          ]
        },
        totalCalories: 1000,
        totalMacros: { protein: 77, carbs: 115, fat: 26 },
        waterIntake: 2.5
      }
    ];

    await Nutrition.insertMany(nutritionLogs);
    console.log('🍎 Created sample nutrition logs');

    // Create sample progress entries
    const progressEntries = [
      {
        user: createdUsers[0]._id,
        date: new Date('2024-01-01'),
        weight: 77,
        bodyMeasurements: {
          chest: 95,
          waist: 85,
          hips: 92
        },
        mood: 'good',
        energyLevel: 7,
        sleepHours: 8
      },
      {
        user: createdUsers[0]._id,
        date: new Date('2024-01-15'),
        weight: 75,
        bodyMeasurements: {
          chest: 94,
          waist: 83,
          hips: 91
        },
        mood: 'excellent',
        energyLevel: 8,
        sleepHours: 7.5
      }
    ];

    await Progress.insertMany(progressEntries);
    console.log('📊 Created sample progress entries');

    console.log('✅ Sample data seeded successfully!');
    console.log('📧 Test account: john@example.com / password123');
    console.log('📧 Test account: jane@example.com / password123');
    
    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding data:', error);
    process.exit(1);
  }
};

seedData();