const express = require('express');
const { body } = require('express-validator');
const workoutController = require('../controllers/workoutController');
const auth = require('../middleware/auth');

const router = express.Router();

// Create workout
router.post('/', [
  auth,
  body('name').notEmpty().withMessage('Workout name is required'),
  body('duration').isNumeric().withMessage('Duration must be a number'),
  body('exercises').isArray().withMessage('Exercises must be an array')
], workoutController.createWorkout);

// Get all workouts
router.get('/', auth, workoutController.getWorkouts);

// Get workout stats
router.get('/stats', auth, workoutController.getWorkoutStats);

// Get single workout
router.get('/:id', auth, workoutController.getWorkout);

// Update workout
router.put('/:id', [
  auth,
  body('name').optional().notEmpty().withMessage('Workout name cannot be empty'),
  body('duration').optional().isNumeric().withMessage('Duration must be a number')
], workoutController.updateWorkout);

// Delete workout
router.delete('/:id', auth, workoutController.deleteWorkout);

module.exports = router;