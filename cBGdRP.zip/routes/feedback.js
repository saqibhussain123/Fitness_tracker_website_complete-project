const express = require('express');
const { body } = require('express-validator');
const feedbackController = require('../controllers/feedbackController');
const auth = require('../middleware/auth');

const router = express.Router();

// Create feedback
router.post('/', [
  auth,
  body('type').isIn(['bug_report', 'feature_request', 'general_feedback', 'support'])
    .withMessage('Invalid feedback type'),
  body('subject').notEmpty().withMessage('Subject is required'),
  body('message').notEmpty().withMessage('Message is required'),
  body('priority').optional().isIn(['low', 'medium', 'high'])
], feedbackController.createFeedback);

// Get all feedback
router.get('/', auth, feedbackController.getFeedback);

// Get single feedback
router.get('/:id', auth, feedbackController.getFeedbackItem);

// Update feedback
router.put('/:id', auth, feedbackController.updateFeedback);

// Delete feedback
router.delete('/:id', auth, feedbackController.deleteFeedback);

module.exports = router;