const express = require('express');
const { body } = require('express-validator');
const userController = require('../controllers/userController');
const auth = require('../middleware/auth');

const router = express.Router();

// Get user profile
router.get('/profile', auth, userController.getProfile);

// Update user profile
router.put('/profile', [
  auth,
  body('name').optional().trim().isLength({ min: 2, max: 50 }),
  body('email').optional().isEmail().normalizeEmail(),
  body('profile.age').optional().isInt({ min: 13, max: 120 }),
  body('profile.height').optional().isFloat({ min: 100, max: 250 }),
  body('profile.currentWeight').optional().isFloat({ min: 30, max: 300 }),
  body('profile.targetWeight').optional().isFloat({ min: 30, max: 300 })
], userController.updateProfile);

// Update user settings
router.put('/settings', auth, userController.updateSettings);

// Delete user account
router.delete('/account', auth, userController.deleteAccount);

module.exports = router;