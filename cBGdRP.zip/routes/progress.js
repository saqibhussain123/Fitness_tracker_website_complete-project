const express = require('express');
const { body } = require('express-validator');
const progressController = require('../controllers/progressController');
const auth = require('../middleware/auth');

const router = express.Router();

// Create progress entry
router.post('/', [
  auth,
  body('weight').isNumeric().withMessage('Weight must be a number'),
  body('date').optional().isISO8601().withMessage('Invalid date format'),
  body('bodyFatPercentage').optional().isFloat({ min: 0, max: 100 }),
  body('energyLevel').optional().isInt({ min: 1, max: 10 }),
  body('sleepHours').optional().isFloat({ min: 0, max: 24 })
], progressController.createProgress);

// Get all progress entries
router.get('/', auth, progressController.getProgress);

// Get progress stats
router.get('/stats', auth, progressController.getProgressStats);

// Get single progress entry
router.get('/:id', auth, progressController.getProgressEntry);

// Update progress entry
router.put('/:id', [
  auth,
  body('weight').optional().isNumeric().withMessage('Weight must be a number'),
  body('bodyFatPercentage').optional().isFloat({ min: 0, max: 100 }),
  body('energyLevel').optional().isInt({ min: 1, max: 10 }),
  body('sleepHours').optional().isFloat({ min: 0, max: 24 })
], progressController.updateProgress);

// Delete progress entry
router.delete('/:id', auth, progressController.deleteProgress);

module.exports = router;