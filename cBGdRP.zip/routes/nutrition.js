const express = require('express');
const { body } = require('express-validator');
const nutritionController = require('../controllers/nutritionController');
const auth = require('../middleware/auth');

const router = express.Router();

// Create nutrition log
router.post('/', [
  auth,
  body('date').optional().isISO8601().withMessage('Invalid date format'),
  body('totalCalories').isNumeric().withMessage('Total calories must be a number'),
  body('waterIntake').optional().isNumeric().withMessage('Water intake must be a number')
], nutritionController.createNutritionLog);

// Get all nutrition logs
router.get('/', auth, nutritionController.getNutritionLogs);

// Get nutrition stats
router.get('/stats', auth, nutritionController.getNutritionStats);

// Get single nutrition log
router.get('/:id', auth, nutritionController.getNutritionLog);

// Update nutrition log
router.put('/:id', [
  auth,
  body('totalCalories').optional().isNumeric().withMessage('Total calories must be a number'),
  body('waterIntake').optional().isNumeric().withMessage('Water intake must be a number')
], nutritionController.updateNutritionLog);

// Delete nutrition log
router.delete('/:id', auth, nutritionController.deleteNutritionLog);

module.exports = router;