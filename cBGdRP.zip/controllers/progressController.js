const Progress = require('../models/Progress');
const { validationResult } = require('express-validator');

exports.createProgress = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const progress = new Progress({
      ...req.body,
      user: req.user.id
    });

    await progress.save();
    
    res.status(201).json({
      message: 'Progress entry created successfully',
      progress
    });
  } catch (error) {
    console.error('Create progress error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getProgress = async (req, res) => {
  try {
    const { page = 1, limit = 10, startDate, endDate } = req.query;
    
    let filter = { user: req.user.id };
    
    if (startDate && endDate) {
      filter.date = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }

    const progress = await Progress.find(filter)
      .sort({ date: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Progress.countDocuments(filter);

    res.json({
      progress,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    console.error('Get progress error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getProgressEntry = async (req, res) => {
  try {
    const progress = await Progress.findOne({
      _id: req.params.id,
      user: req.user.id
    });

    if (!progress) {
      return res.status(404).json({ message: 'Progress entry not found' });
    }

    res.json(progress);
  } catch (error) {
    console.error('Get progress entry error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.updateProgress = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const progress = await Progress.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      req.body,
      { new: true, runValidators: true }
    );

    if (!progress) {
      return res.status(404).json({ message: 'Progress entry not found' });
    }

    res.json({
      message: 'Progress updated successfully',
      progress
    });
  } catch (error) {
    console.error('Update progress error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.deleteProgress = async (req, res) => {
  try {
    const progress = await Progress.findOneAndDelete({
      _id: req.params.id,
      user: req.user.id
    });

    if (!progress) {
      return res.status(404).json({ message: 'Progress entry not found' });
    }

    res.json({ message: 'Progress entry deleted successfully' });
  } catch (error) {
    console.error('Delete progress error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getProgressStats = async (req, res) => {
  try {
    const latestProgress = await Progress.findOne({ user: req.user.id })
      .sort({ date: -1 });

    const firstProgress = await Progress.findOne({ user: req.user.id })
      .sort({ date: 1 });

    const weightTrend = await Progress.find({ user: req.user.id })
      .sort({ date: -1 })
      .limit(30)
      .select('date weight');

    const stats = {
      currentWeight: latestProgress?.weight || 0,
      startingWeight: firstProgress?.weight || 0,
      weightChange: latestProgress && firstProgress 
        ? latestProgress.weight - firstProgress.weight 
        : 0,
      totalEntries: await Progress.countDocuments({ user: req.user.id }),
      latestEntry: latestProgress,
      weightTrend: weightTrend.reverse()
    };

    res.json(stats);
  } catch (error) {
    console.error('Get progress stats error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};