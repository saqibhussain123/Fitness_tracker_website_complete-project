const Nutrition = require('../models/Nutrition');
const { validationResult } = require('express-validator');

exports.createNutritionLog = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const nutrition = new Nutrition({
      ...req.body,
      user: req.user.id
    });

    await nutrition.save();
    
    res.status(201).json({
      message: 'Nutrition log created successfully',
      nutrition
    });
  } catch (error) {
    console.error('Create nutrition error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getNutritionLogs = async (req, res) => {
  try {
    const { page = 1, limit = 10, startDate, endDate } = req.query;
    
    let filter = { user: req.user.id };
    
    if (startDate && endDate) {
      filter.date = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }

    const logs = await Nutrition.find(filter)
      .sort({ date: -1 })
      .limit(limit * 1)
      .skip((page - 1) * limit);

    const total = await Nutrition.countDocuments(filter);

    res.json({
      logs,
      totalPages: Math.ceil(total / limit),
      currentPage: page,
      total
    });
  } catch (error) {
    console.error('Get nutrition logs error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getNutritionLog = async (req, res) => {
  try {
    const log = await Nutrition.findOne({
      _id: req.params.id,
      user: req.user.id
    });

    if (!log) {
      return res.status(404).json({ message: 'Nutrition log not found' });
    }

    res.json(log);
  } catch (error) {
    console.error('Get nutrition log error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.updateNutritionLog = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const log = await Nutrition.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      req.body,
      { new: true, runValidators: true }
    );

    if (!log) {
      return res.status(404).json({ message: 'Nutrition log not found' });
    }

    res.json({
      message: 'Nutrition log updated successfully',
      log
    });
  } catch (error) {
    console.error('Update nutrition log error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.deleteNutritionLog = async (req, res) => {
  try {
    const log = await Nutrition.findOneAndDelete({
      _id: req.params.id,
      user: req.user.id
    });

    if (!log) {
      return res.status(404).json({ message: 'Nutrition log not found' });
    }

    res.json({ message: 'Nutrition log deleted successfully' });
  } catch (error) {
    console.error('Delete nutrition log error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.getNutritionStats = async (req, res) => {
  try {
    const stats = await Nutrition.aggregate([
      { $match: { user: req.user._id } },
      {
        $group: {
          _id: null,
          totalLogs: { $sum: 1 },
          avgCalories: { $avg: '$totalCalories' },
          avgProtein: { $avg: '$totalMacros.protein' },
          avgCarbs: { $avg: '$totalMacros.carbs' },
          avgFat: { $avg: '$totalMacros.fat' },
          avgWater: { $avg: '$waterIntake' }
        }
      }
    ]);

    const recentLogs = await Nutrition.find({ user: req.user.id })
      .sort({ date: -1 })
      .limit(7)
      .select('date totalCalories totalMacros waterIntake');

    res.json({
      stats: stats[0] || {
        totalLogs: 0,
        avgCalories: 0,
        avgProtein: 0,
        avgCarbs: 0,
        avgFat: 0,
        avgWater: 0
      },
      recentLogs
    });
  } catch (error) {
    console.error('Get nutrition stats error:', error);
    res.status(500).json({ message: 'Server error' });
  }
};